"use client"

import { useState, useEffect, useCallback } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import {
    ScrollText, Search, Filter, Download, CheckCircle, XCircle,
    Clock, Loader2, User, ChevronDown
} from "lucide-react"

const STATUS_COLOR: Record<string, string> = {
    success: 'text-emerald-600',
    failed: 'text-red-600',
    pending: 'text-amber-600',
}

export default function AdminActivityLogsPage() {
    const { t } = useI18n()

    const [logs, setLogs] = useState<any[]>([])
    const [loading, setLoading] = useState(true)
    const [total, setTotal] = useState(0)
    const [page, setPage] = useState(1)
    const [availableActions, setAvailableActions] = useState<string[]>([])

    const [search, setSearch] = useState('')
    const [filterAction, setFilterAction] = useState('')
    const [filterDateFrom, setFilterDateFrom] = useState('')
    const [filterDateTo, setFilterDateTo] = useState('')

    const fetchLogs = useCallback(async () => {
        setLoading(true)
        try {
            const params = new URLSearchParams({ page: String(page) })
            if (search) params.set('search', search)
            if (filterAction) params.set('action', filterAction)
            if (filterDateFrom) params.set('dateFrom', filterDateFrom)
            if (filterDateTo) params.set('dateTo', filterDateTo)
            const res = await fetch(`/api/admin/activity-logs?${params}`)
            if (res.ok) {
                const data = await res.json()
                setLogs(data.logs)
                setTotal(data.total)
                if (data.actions?.length) setAvailableActions(data.actions)
            }
        } finally {
            setLoading(false)
        }
    }, [page, search, filterAction, filterDateFrom, filterDateTo])

    useEffect(() => {
        const timeout = setTimeout(fetchLogs, 300)
        return () => clearTimeout(timeout)
    }, [fetchLogs])

    const totalPages = Math.ceil(total / 50)

    const handleExport = () => {
        const csv = [
            ['التاريخ', 'المستخدم', 'الدور', 'الإجراء', 'النوع', 'الوصف', 'الحالة', 'IP'].join(','),
            ...logs.map(l => [
                new Date(l.created_at).toISOString(),
                l.user_name || 'النظام',
                l.user_role || '',
                l.action,
                l.entity_type || '',
                l.description || '',
                l.status,
                l.ip_address || '',
            ].join(','))
        ].join('\n')

        const blob = new Blob([csv], { type: 'text/csv' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `activity-logs-${new Date().toISOString().slice(0, 10)}.csv`
        a.click()
        URL.revokeObjectURL(url)
    }

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-foreground">سجل الأنشطة</h1>
                    <p className="text-sm text-muted-foreground mt-1">تتبع وتدقيق جميع الأنشطة في النظام</p>
                </div>
                <Button variant="outline" onClick={handleExport}>
                    <Download className="w-4 h-4 ml-2" /> تصدير CSV
                </Button>
            </div>

            {/* Filters */}
            <div className="bg-card border border-border rounded-2xl p-4 flex flex-wrap gap-3">
                <div className="relative flex-1 min-w-[180px]">
                    <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input className="pr-10" placeholder="بحث..." value={search} onChange={e => { setSearch(e.target.value); setPage(1) }} />
                </div>
                <select
                    className="h-10 rounded-xl border border-border bg-background px-3 text-sm min-w-[160px]"
                    value={filterAction}
                    onChange={e => { setFilterAction(e.target.value); setPage(1) }}
                >
                    <option value="">جميع الإجراءات</option>
                    {availableActions.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
                <Input type="date" className="w-40 h-10" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} placeholder="من" />
                <Input type="date" className="w-40 h-10" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} placeholder="إلى" />
                {(search || filterAction || filterDateFrom || filterDateTo) && (
                    <Button variant="ghost" size="sm" onClick={() => { setSearch(''); setFilterAction(''); setFilterDateFrom(''); setFilterDateTo(''); setPage(1) }}>
                        مسح
                    </Button>
                )}
            </div>

            {/* Logs Table */}
            <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
                <div className="p-5 border-b border-border/50 bg-muted/30">
                    <h3 className="font-bold text-foreground">
                        السجل <span className="text-muted-foreground font-normal text-sm">({total} إجمالي)</span>
                    </h3>
                </div>

                {loading ? (
                    <div className="flex justify-center p-16"><Loader2 className="w-7 h-7 animate-spin text-primary" /></div>
                ) : logs.length === 0 ? (
                    <div className="p-12 text-center text-muted-foreground">لا توجد أنشطة مسجلة</div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-border text-muted-foreground bg-muted/20">
                                    <th className="text-right py-3 px-4 font-medium">التاريخ</th>
                                    <th className="text-right py-3 px-4 font-medium">المستخدم</th>
                                    <th className="text-right py-3 px-4 font-medium">الإجراء</th>
                                    <th className="text-right py-3 px-4 font-medium">النوع</th>
                                    <th className="text-right py-3 px-4 font-medium">الوصف</th>
                                    <th className="text-right py-3 px-4 font-medium">الحالة</th>
                                    <th className="text-right py-3 px-4 font-medium">IP</th>
                                </tr>
                            </thead>
                            <tbody>
                                {logs.map(l => (
                                    <tr key={l.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                                        <td className="py-2.5 px-4 text-xs text-muted-foreground whitespace-nowrap">
                                            {new Date(l.created_at).toLocaleString('ar-SA', { dateStyle: 'short', timeStyle: 'short' })}
                                        </td>
                                        <td className="py-2.5 px-4">
                                            <div className="flex items-center gap-1.5">
                                                <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center text-[10px] font-bold">
                                                    {l.user_name?.[0] || '?'}
                                                </div>
                                                <div>
                                                    <p className="text-xs font-medium text-foreground">{l.user_name || 'النظام'}</p>
                                                    {l.user_role && <p className="text-[10px] text-muted-foreground">{l.user_role === 'admin' ? 'أدمن' : l.user_role === 'reader' ? 'مقرئ' : 'طالب'}</p>}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="py-2.5 px-4">
                                            <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{l.action}</code>
                                        </td>
                                        <td className="py-2.5 px-4 text-xs text-muted-foreground">{l.entity_type || '—'}</td>
                                        <td className="py-2.5 px-4 text-xs text-muted-foreground max-w-[200px] truncate">{l.description || '—'}</td>
                                        <td className="py-2.5 px-4">
                                            <span className={`text-xs font-bold ${STATUS_COLOR[l.status] || 'text-muted-foreground'}`}>
                                                {l.status === 'success' ? 'ناجح' : l.status === 'failed' ? 'فاشل' : 'جاري'}
                                            </span>
                                        </td>
                                        <td className="py-2.5 px-4 text-xs text-muted-foreground font-mono">{l.ip_address || '—'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {totalPages > 1 && (
                    <div className="flex items-center justify-between p-4 border-t border-border/50">
                        <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>السابق</Button>
                        <span className="text-sm text-muted-foreground">صفحة {page} من {totalPages}</span>
                        <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>التالي</Button>
                    </div>
                )}
            </div>
        </div>
    )
}
