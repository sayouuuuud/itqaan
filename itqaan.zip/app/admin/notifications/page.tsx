import NotificationsPage from "@/components/notifications-page"
export default NotificationsPage
