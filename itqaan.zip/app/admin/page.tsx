"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useI18n } from "@/lib/i18n/context"
import { StatusBadge } from "@/components/status-badge"
import {
  Users, BookOpen, ClipboardList, Clock, ArrowLeft,
  TrendingUp, Download, UserCheck, Loader2
} from "lucide-react"

export default function AdminDashboard() {
  const { t } = useI18n()
  const isAr = t.locale === "ar"

  const [data, setData] = useState<{ stats: any, latestRecitations: any[] } | null>(null)
  const [loading, setLoading] = useState(true)
  const [analytics, setAnalytics] = useState<any>(null)

  useEffect(() => {
    async function loadStats() {
      try {
        const res = await fetch("/api/admin/stats")
        if (res.ok) {
          const json = await res.json()
          setData(json)
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    loadStats()
    // Load analytics in parallel
    fetch('/api/admin/analytics?days=30').then(r => r.ok ? r.json() : null).then(d => {
      if (d) setAnalytics(d)
    }).catch(() => { })
  }, [])

  if (loading || !data) {
    return (
      <div className="flex justify-center p-20">
        <Loader2 className="w-8 h-8 animate-spin text-[#0B3D2E]" />
      </div>
    )
  }

  const { stats, latestRecitations } = data

  const statCards = [
    { label: t.admin.totalStudents, value: stats.totalStudents, icon: Users, iconBg: "bg-primary/10 text-primary" },
    { label: t.admin.totalReaders, value: stats.totalReaders, icon: BookOpen, iconBg: "bg-emerald-50 text-emerald-600" },
    { label: t.admin.todaysRecitations, value: stats.recitationsToday, icon: ClipboardList, iconBg: "bg-blue-50 text-blue-600" },
    { label: t.admin.avgReviewTime, value: stats.avgReviewTime, icon: Clock, iconBg: "bg-amber-50 text-amber-600" },
    { label: t.admin.pendingReaderApps, value: stats.pendingReaderApps, icon: UserCheck, iconBg: "bg-orange-50 text-orange-600" },
  ]

  const pieData = Object.entries(stats.statusDistribution).map(([key, value]) => ({
    key,
    name: key === "pending" ? t.admin.pending : key === "in_review" ? t.admin.underReview : key === "mastered" ? t.admin.mastered : key === "needs_session" ? (isAr ? "يحتاج جلسة" : "Needs Session") : key === "session_booked" ? (isAr ? "تم حجز الموعد" : "Session Booked") : key,
    value: value as number,
    color: key === "pending" ? "#f59e0b" : key === "in_review" ? "#3b82f6" : key === "mastered" ? "#10b981" : key === "needs_session" ? "#D4A843" : key === "session_booked" ? "#8b5cf6" : "#ef4444",
  }))

  const totalPie = pieData.reduce((sum, d) => sum + d.value, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">{t.admin.adminDashboard}</h1>
          <p className="text-sm text-muted-foreground mt-1">{t.admin.systemOverview}</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-muted transition-colors">
          <Download className="w-4 h-4" />
          {t.admin.exportCsv}
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="bg-card p-6 rounded-2xl border border-border shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stat.value}</p>
              </div>
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${stat.iconBg}`}>
                <stat.icon className="w-5 h-5" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recitations Over Time */}
        <div className="bg-card rounded-2xl border border-border shadow-sm p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-bold text-foreground">{t.admin.recitationsOverTime}</h3>
              <p className="text-sm text-muted-foreground">{t.admin.last30Days}</p>
            </div>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="h-[200px] flex items-end justify-between gap-3 px-2">
            {stats.recitationsOverTime.map((d: any) => (
              <div key={d.date} className="w-full relative h-full flex flex-col items-center justify-end gap-1">
                <span className="text-xs font-bold text-foreground">{d.count}</span>
                <div
                  className="w-full bg-primary/80 hover:bg-primary rounded-t-lg transition-colors"
                  style={{ height: `${Math.max((d.count / (Math.max(...stats.recitationsOverTime.map((r: any) => r.count)) || 1)) * 100, 5)}%` }}
                />
                <span className="text-xs text-muted-foreground mt-1">{d.date}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Status Distribution */}
        <div className="bg-card rounded-2xl border border-border shadow-sm p-6">
          <h3 className="font-bold text-foreground mb-2">{t.admin.statusDistribution}</h3>
          <p className="text-sm text-muted-foreground mb-6">{t.admin.totalByStatus}</p>

          <div className="flex items-center justify-center mb-6">
            <div className="relative w-40 h-40">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                {pieData.reduce((acc, d, i) => {
                  const pct = totalPie > 0 ? (d.value / totalPie) * 100 : 0
                  const offset = acc.offset
                  if (pct > 0) {
                    acc.elements.push(
                      <circle
                        key={d.key}
                        cx="18" cy="18" r="15.9"
                        fill="none"
                        stroke={d.color}
                        strokeWidth="3"
                        strokeDasharray={`${pct} ${100 - pct}`}
                        strokeDashoffset={`${-offset}`}
                      />
                    )
                  }
                  acc.offset += pct
                  return acc
                }, { elements: [] as React.ReactNode[], offset: 0 }).elements}
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <span className="text-2xl font-bold text-foreground">{totalPie}</span>
                  <span className="block text-xs text-muted-foreground">{t.admin.total}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            {pieData.map((item) => (
              <div key={item.key} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-muted-foreground">{item.name}</span>
                </div>
                <span className="font-medium text-foreground">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>


      {/* Visitor Analytics Section */}
      {analytics && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-gray-800">{t.admin.visitorAnalytics}</h2>
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">{t.admin.last30Days}</span>
          </div>
          {/* Overview */}
          <div className="grid grid-cols-3 gap-4">
            {[
              { label: t.admin.totalViews, value: parseInt(analytics.overview?.total_views || '0').toLocaleString(), sub: t.admin.todayLabel + ': ' + (analytics.overview?.today_views || 0) },
              { label: t.admin.uniqueVisitors, value: parseInt(analytics.overview?.unique_visitors || '0').toLocaleString(), sub: t.admin.weekLabel + ': ' + (analytics.overview?.week_visitors || 0) },
              { label: t.admin.todayVisitors, value: parseInt(analytics.overview?.today_visitors || '0').toLocaleString(), sub: t.admin.weekViews + ': ' + (analytics.overview?.week_views || 0) },
            ].map(c => (
              <div key={c.label} className="bg-blue-50 rounded-xl p-4">
                <p className="text-2xl font-bold text-blue-700">{c.value}</p>
                <p className="text-xs text-gray-600 mt-1">{c.label}</p>
                <p className="text-xs text-blue-400 mt-0.5">{c.sub}</p>
              </div>
            ))}
          </div>
          {/* Charts: Visitor trend + Top pages + Countries + Devices */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Visitor Trend */}
            <div className="bg-card rounded-xl border border-border shadow-sm p-4 lg:col-span-2">
              <p className="font-semibold text-sm text-gray-700 mb-3">{t.admin.dailyVisits}</p>
              <div className="h-[120px] flex items-end gap-0.5">
                {(analytics.overTime || []).slice(-30).map((d: any, i: number) => {
                  const max = Math.max(...(analytics.overTime || []).map((x: any) => parseInt(x.views || 0)))
                  const h = max > 0 ? Math.max((parseInt(d.views || 0) / max) * 100, 4) : 4
                  return (
                    <div key={i} className="flex-1 flex flex-col items-center justify-end" title={`${d.day}: ${d.views} views`}>
                      <div className="w-full bg-blue-400 hover:bg-blue-500 rounded-t transition-colors" style={{ height: `${h}%` }} />
                    </div>
                  )
                })}
              </div>
            </div>
            {/* Countries + Devices */}
            <div className="space-y-4">
              <div className="bg-card rounded-xl border border-border shadow-sm p-4">
                <p className="font-semibold text-sm text-gray-700 mb-3">{t.admin.topCountries}</p>
                <div className="space-y-2">
                  {(analytics.topCountries || []).slice(0, 5).map((c: any, i: number) => (
                    <div key={i} className="flex items-center justify-between text-xs">
                      <span className="text-gray-700 truncate">{c.country}</span>
                      <span className="font-bold text-gray-800">{c.views}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-card rounded-xl border border-border shadow-sm p-4">
                <p className="font-semibold text-sm text-gray-700 mb-3">{t.admin.deviceTypes}</p>
                <div className="space-y-1.5">
                  {(analytics.deviceTypes || []).map((d: any, i: number) => {
                    const total = (analytics.deviceTypes || []).reduce((s: number, x: any) => s + parseInt(x.count || 0), 0)
                    const pct = total > 0 ? Math.round(parseInt(d.count || 0) * 100 / total) : 0
                    const icons: Record<string, string> = { desktop: '🖥️', mobile: '📱', tablet: '📲', unknown: '❓' }
                    return (
                      <div key={i} className="text-xs">
                        <div className="flex justify-between mb-0.5">
                          <span>{icons[d.device_type] || '❓'} {d.device_type}</span>
                          <span className="font-bold">{pct}%</span>
                        </div>
                        <div className="h-1.5 bg-gray-100 rounded-full"><div className="h-full bg-blue-400 rounded-full" style={{ width: `${pct}%` }} /></div>
                      </div>
                    )
                  })}
                </div>
              </div>
            </div>
          </div>
          {/* Top Pages */}
          <div className="bg-card rounded-xl border border-border shadow-sm p-4">
            <p className="font-semibold text-sm text-gray-700 mb-3">{t.admin.topPages}</p>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="pb-2 text-gray-500 font-medium text-start">{t.admin.pageLabel}</th>
                    <th className="pb-2 text-gray-500 font-medium text-end">{t.admin.viewsLabel}</th>
                    <th className="pb-2 text-gray-500 font-medium text-end">{t.admin.visitorsLabel}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {(analytics.topPages || []).slice(0, 10).map((p: any, i: number) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="py-1.5 font-mono text-gray-700 max-w-[300px] truncate">{p.path}</td>
                      <td className="py-1.5 text-end font-bold text-blue-600">{p.views}</td>
                      <td className="py-1.5 text-end text-gray-500">{p.visitors}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Readers Activity */}
      <div className="bg-card rounded-2xl border border-border shadow-sm p-6">
        <h3 className="font-bold text-foreground mb-4">{t.admin.readerActivity}</h3>
        <div className="space-y-4">
          {stats.readersActivity.length > 0 ? stats.readersActivity.map((reader: any) => (
            <div key={reader.name} className="flex items-center gap-4">
              <span className="text-sm font-medium text-foreground min-w-[120px]">{reader.name}</span>
              <div className="flex-1 h-6 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all"
                  style={{ width: `${(reader.reviews / (Math.max(...stats.readersActivity.map((r: any) => r.reviews)) || 1)) * 100}%` }}
                />
              </div>
              <span className="text-sm font-bold text-foreground min-w-[40px] text-left">{reader.reviews}</span>
            </div>
          )) : (
            <p className="text-sm text-muted-foreground">{t.admin.noReaderActivity}</p>
          )}
        </div>
      </div>

      {/* Latest Recitations Table */}
      <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
        <div className="p-6 border-b border-border/50 flex items-center justify-between bg-muted/30">
          <div>
            <h3 className="font-bold text-foreground">{t.admin.latestRecitations}</h3>
            <p className="text-sm text-muted-foreground">{t.admin.mostRecentSubmissions}</p>
          </div>
          <Link href="/admin/recitations" className="text-sm text-primary font-medium hover:underline flex items-center gap-1">
            {t.admin.viewAll}
            <ArrowLeft className="w-3 h-3" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-muted-foreground">
                <th className="text-right py-3 px-6 font-medium">{t.admin.student}</th>
                <th className="text-right py-3 px-6 font-medium">{t.admin.surah}</th>
                <th className="text-right py-3 px-6 font-medium">{t.admin.reader}</th>
                <th className="text-right py-3 px-6 font-medium">{t.admin.status}</th>
                <th className="text-right py-3 px-6 font-medium">{t.admin.date}</th>
              </tr>
            </thead>
            <tbody>
              {latestRecitations.length > 0 ? latestRecitations.map((rec: any) => (
                <tr key={rec.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                  <td className="py-3 px-6 font-medium text-foreground">{rec.studentName}</td>
                  <td className="py-3 px-6 text-muted-foreground">{rec.surah} ({rec.fromAyah}-{rec.toAyah})</td>
                  <td className="py-3 px-6 text-muted-foreground">{rec.assignedReaderName || "---"}</td>
                  <td className="py-3 px-6"><StatusBadge status={rec.status as any} /></td>
                  <td className="py-3 px-6 text-muted-foreground text-xs">{new Date(rec.createdAt).toLocaleDateString(t.locale === 'ar' ? "ar-SA" : "en-US")}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={5} className="py-6 text-center text-muted-foreground">
                    {t.admin.noRecentRecitations}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
