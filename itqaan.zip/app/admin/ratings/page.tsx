"use client"

import { useState, useEffect, useCallback } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Star, Filter, Loader2, Trash2 } from "lucide-react"

const STARS = [1, 2, 3, 4, 5]

function StarRating({ value }: { value: number }) {
    return (
        <span className="flex gap-0.5">
            {STARS.map(s => (
                <Star key={s} className={`w-3 h-3 ${s <= value ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}`} />
            ))}
        </span>
    )
}

export default function AdminRatingsPage() {
    const { t } = useI18n()

    const [ratings, setRatings] = useState<any[]>([])
    const [readerAverages, setReaderAverages] = useState<any[]>([])
    const [loading, setLoading] = useState(true)
    const [total, setTotal] = useState(0)
    const [page, setPage] = useState(1)
    const [filterReader, setFilterReader] = useState('')
    const [deletingId, setDeletingId] = useState<string | null>(null)

    const fetchRatings = useCallback(async () => {
        setLoading(true)
        try {
            const params = new URLSearchParams({ page: String(page) })
            if (filterReader) params.set('readerId', filterReader)
            const res = await fetch(`/api/admin/ratings?${params}`)
            if (res.ok) {
                const data = await res.json()
                setRatings(data.ratings)
                setTotal(data.total)
                if (data.readerAverages) setReaderAverages(data.readerAverages)
            }
        } finally {
            setLoading(false)
        }
    }, [page, filterReader])

    useEffect(() => { fetchRatings() }, [fetchRatings])

    const handleDelete = async (id: string) => {
        if (!confirm('هل أنت متأكد من حذف هذا التقييم؟')) return
        setDeletingId(id)
        try {
            await fetch('/api/admin/ratings', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id }),
            })
            fetchRatings()
        } finally {
            setDeletingId(null)
        }
    }

    const totalPages = Math.ceil(total / 20)

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-foreground">تقييمات المقرئين</h1>
                <p className="text-sm text-muted-foreground mt-1">تقييمات الطلاب للمقرئين بعد الجلسات</p>
            </div>

            {/* Top Readers Leaderboard */}
            {readerAverages.length > 0 && (
                <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                    <h3 className="font-bold text-foreground mb-4">ترتيب المقرئين حسب التقييم</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                        {readerAverages.map((r, i) => (
                            <button
                                key={r.reader_id}
                                onClick={() => setFilterReader(filterReader === r.reader_id ? '' : r.reader_id)}
                                className={`p-3 rounded-xl text-center border transition-colors ${filterReader === r.reader_id ? 'border-primary bg-primary/5' : 'border-border hover:bg-muted/40'}`}
                            >
                                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#0B3D2E] to-[#1A6B4A] flex items-center justify-center text-white font-bold text-sm mx-auto mb-2">
                                    {i + 1}
                                </div>
                                <p className="text-xs font-bold text-foreground truncate">{r.reader_name}</p>
                                <div className="flex items-center justify-center gap-1 mt-1">
                                    <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                                    <span className="text-xs font-bold text-amber-600">{Number(r.avg_rating).toFixed(1)}</span>
                                </div>
                                <p className="text-[10px] text-muted-foreground">{r.total_ratings} تقييم</p>
                            </button>
                        ))}
                    </div>
                </div>
            )}

            {/* Ratings Table */}
            <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
                <div className="p-5 border-b border-border/50 bg-muted/30 flex items-center justify-between">
                    <h3 className="font-bold text-foreground">
                        التقييمات <span className="text-muted-foreground font-normal text-sm">({total})</span>
                    </h3>
                    {filterReader && (
                        <Button variant="ghost" size="sm" onClick={() => setFilterReader('')}>مسح الفلتر</Button>
                    )}
                </div>

                {loading ? (
                    <div className="flex justify-center p-16"><Loader2 className="w-7 h-7 animate-spin text-primary" /></div>
                ) : ratings.length === 0 ? (
                    <div className="p-12 text-center text-muted-foreground">لا توجد تقييمات</div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-border bg-muted/20 text-muted-foreground">
                                    <th className="text-right py-3 px-4 font-medium">الطالب</th>
                                    <th className="text-right py-3 px-4 font-medium">المقرئ</th>
                                    <th className="text-right py-3 px-4 font-medium">التقييم</th>
                                    <th className="text-right py-3 px-4 font-medium">التجويد</th>
                                    <th className="text-right py-3 px-4 font-medium">التواصل</th>
                                    <th className="text-right py-3 px-4 font-medium">الالتزام</th>
                                    <th className="text-right py-3 px-4 font-medium">التعليق</th>
                                    <th className="text-right py-3 px-4 font-medium">تاريخ الجلسة</th>
                                    <th className="py-3 px-4"></th>
                                </tr>
                            </thead>
                            <tbody>
                                {ratings.map(r => (
                                    <tr key={r.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                                        <td className="py-3 px-4 font-medium text-foreground">{r.student_name}</td>
                                        <td className="py-3 px-4 text-muted-foreground">{r.reader_name}</td>
                                        <td className="py-3 px-4"><StarRating value={r.rating} /></td>
                                        <td className="py-3 px-4"><StarRating value={r.teaching_quality} /></td>
                                        <td className="py-3 px-4"><StarRating value={r.communication} /></td>
                                        <td className="py-3 px-4"><StarRating value={r.punctuality} /></td>
                                        <td className="py-3 px-4 max-w-[150px]">
                                            <p className="text-xs text-muted-foreground truncate">{r.feedback_text || '—'}</p>
                                        </td>
                                        <td className="py-3 px-4 text-xs text-muted-foreground whitespace-nowrap">
                                            {r.session_date ? new Date(r.session_date).toLocaleDateString('ar-SA') : '—'}
                                        </td>
                                        <td className="py-3 px-4">
                                            <Button variant="ghost" size="sm" onClick={() => handleDelete(r.id)} disabled={deletingId === r.id}>
                                                {deletingId === r.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5 text-red-400" />}
                                            </Button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}

                {totalPages > 1 && (
                    <div className="flex items-center justify-between p-4 border-t border-border/50">
                        <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>السابق</Button>
                        <span className="text-sm text-muted-foreground">صفحة {page} من {totalPages}</span>
                        <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>التالي</Button>
                    </div>
                )}
            </div>
        </div>
    )
}
