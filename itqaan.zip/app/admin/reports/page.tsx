'use client'

import { useState, useEffect } from 'react'
import { BarChart3, TrendingUp, Download, Users, Star, Mail, Award, Loader2, Medal, Clock } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts'
import { useI18n } from '@/lib/i18n/context'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'

const STATUS_COLORS: Record<string, string> = { mastered: '#10b981', needs_session: '#D4A843', pending: '#f59e0b', in_review: '#3b82f6', rejected: '#ef4444', session_booked: '#8b5cf6' }
const STATUS_LABELS: Record<string, string> = { mastered: 'متقن', needs_session: 'يحتاج جلسة', pending: 'قيد المراجعة', in_review: 'جاري المراجعة', rejected: 'مرفوض', session_booked: 'تم الحجز' }

export default function AdminReportsPage() {
  const { t } = useI18n()
  const isAr = t.locale === 'ar'
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const load = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (dateFrom) params.set('dateFrom', dateFrom)
      if (dateTo) params.set('dateTo', dateTo)
      const res = await fetch(`/api/admin/reports?${params}`)
      if (res.ok) setData(await res.json())
    } finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const exportCSV = () => {
    if (!data) return
    const rows = [
      ['المقياس', 'القيمة'],
      ['إجمالي التلاوات', data.recitations?.total],
      ['المتقنين', data.recitations?.mastered],
      ['يحتاج جلسة', data.recitations?.needs_session],
      ['قيد المراجعة', data.recitations?.pending],
      ['نسبة الإتقان', `${data.recitations?.mastery_rate}%`],
      ['إجمالي الجلسات', data.sessions?.total],
      ['جلسات مكتملة', data.sessions?.completed],
      ['جلسات ملغاة', data.sessions?.cancelled],
      ['الشهادات المُصدرة', data.certificates],
      ['الإيميلات المُرسلة', data.emailsSent],
    ]
    const csv = '\uFEFF' + rows.map(r => r.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reports-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  if (loading) return <div className="flex justify-center p-20"><Loader2 className="w-8 h-8 animate-spin text-[#0B3D2E]" /></div>

  const recPieData = ['mastered', 'needs_session', 'pending', 'in_review', 'rejected'].map(s => ({
    name: STATUS_LABELS[s] || s,
    value: data?.recitations?.[s] || 0,
    color: STATUS_COLORS[s],
  })).filter(d => d.value > 0)

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6" dir={isAr ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3">
          <BarChart3 className="w-8 h-8 text-[#0B3D2E]" />
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{isAr ? 'التقارير الشاملة' : 'Comprehensive Reports'}</h1>
            <p className="text-gray-500 text-sm">{isAr ? 'إحصائيات كاملة عن نشاط المنصة' : 'Full platform activity statistics'}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <Label className="text-sm text-gray-600">من</Label>
            <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-36 text-sm" />
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-sm text-gray-600">إلى</Label>
            <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-36 text-sm" />
          </div>
          <Button onClick={load} size="sm" className="bg-[#0B3D2E] text-white hover:bg-[#0B3D2E]/90">تطبيق</Button>
          <Button onClick={exportCSV} size="sm" variant="outline" className="gap-1"><Download className="w-4 h-4" />CSV</Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: isAr ? 'إجمالي التلاوات' : 'Total Recitations', value: data?.recitations?.total || 0, icon: BarChart3, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: isAr ? 'المتقنون' : 'Mastered', value: data?.recitations?.mastered || 0, icon: Award, color: 'text-green-600', bg: 'bg-green-50' },
          { label: isAr ? 'إجمالي الجلسات' : 'Total Sessions', value: data?.sessions?.total || 0, icon: Users, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: isAr ? 'نسبة الإتقان' : 'Mastery Rate', value: `${data?.recitations?.mastery_rate || 0}%`, icon: TrendingUp, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: isAr ? 'جلسات مكتملة' : 'Completed Sessions', value: data?.sessions?.completed || 0, icon: Clock, color: 'text-teal-600', bg: 'bg-teal-50' },
          { label: isAr ? 'يحتاج جلسة' : 'Needs Session', value: data?.recitations?.needs_session || 0, icon: Star, color: 'text-orange-600', bg: 'bg-orange-50' },
          { label: isAr ? 'الشهادات المُصدرة' : 'Certificates Issued', value: data?.certificates || 0, icon: Award, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: isAr ? 'إيميلات أُرسلت' : 'Emails Sent', value: data?.emailsSent || 0, icon: Mail, color: 'text-pink-600', bg: 'bg-pink-50' },
        ].map(card => (
          <div key={card.label} className={`${card.bg} rounded-xl p-4`}>
            <div className="flex items-center gap-3">
              <card.icon className={`w-6 h-6 ${card.color}`} />
              <p className="text-xs text-gray-600">{card.label}</p>
            </div>
            <p className={`text-2xl font-bold mt-2 ${card.color}`}>{typeof card.value === 'number' ? card.value.toLocaleString() : card.value}</p>
          </div>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Monthly Trend */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-800 mb-4">{isAr ? 'التلاوات الشهرية' : 'Monthly Recitations'}</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data?.recitations?.byMonth || []}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Line type="monotone" dataKey="total" stroke="#3b82f6" strokeWidth={2} dot={false} name="إجمالي" />
              <Line type="monotone" dataKey="mastered" stroke="#10b981" strokeWidth={2} dot={false} name="متقن" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Status Pie */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <h3 className="font-semibold text-gray-800 mb-4">{isAr ? 'توزيع الحالات' : 'Status Distribution'}</h3>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={recPieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value">
                  {recPieData.map((entry, index) => <Cell key={index} fill={entry.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 flex-1">
              {recPieData.map(d => (
                <div key={d.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: d.color }} />
                    <span className="text-gray-700">{d.name}</span>
                  </div>
                  <span className="font-semibold text-gray-800">{d.value.toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Mastery Trend */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="font-semibold text-gray-800 mb-4">{isAr ? 'نسبة الإتقان الأسبوعية' : 'Weekly Mastery Rate'}</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data?.masteryTrend || []}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis dataKey="week" tick={{ fontSize: 11 }} />
            <YAxis domain={[0, 100]} tick={{ fontSize: 11 }} unit="%" />
            <Tooltip formatter={(v: any) => [`${v}%`, isAr ? 'نسبة الإتقان' : 'Mastery Rate']} />
            <Bar dataKey="mastery_rate" fill="#10b981" radius={[4, 4, 0, 0]} name={isAr ? 'نسبة الإتقان' : 'Mastery Rate'} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Leaderboards Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Top Reviewers */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <Medal className="w-5 h-5 text-amber-500" />
            <h3 className="font-semibold text-gray-800">{isAr ? 'أعلى المقرئين تصحيحًا' : 'Top Reviewers'}</h3>
          </div>
          <div className="space-y-3">
            {(data?.topReviewers || []).slice(0, 5).map((r: any, i: number) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center ${i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-gray-100 text-gray-600' : i === 2 ? 'bg-orange-100 text-orange-600' : 'bg-gray-50 text-gray-500'}`}>{i + 1}</span>
                  <p className="text-sm text-gray-800 font-medium truncate max-w-[130px]">{r.name}</p>
                </div>
                <div className="text-end">
                  <p className="text-sm font-bold text-[#0B3D2E]">{r.reviews_count}</p>
                  <p className="text-xs text-green-600">{r.mastered_count} متقن</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Session Readers */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <Medal className="w-5 h-5 text-blue-500" />
            <h3 className="font-semibold text-gray-800">{isAr ? 'أعلى المقرئين جلسات' : 'Top Session Readers'}</h3>
          </div>
          <div className="space-y-3">
            {(data?.topSessionReaders || []).slice(0, 5).map((r: any, i: number) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center ${i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-gray-100 text-gray-600' : 'bg-gray-50 text-gray-500'}`}>{i + 1}</span>
                  <p className="text-sm text-gray-800 font-medium truncate max-w-[130px]">{r.name}</p>
                </div>
                <div className="text-end">
                  <p className="text-sm font-bold text-blue-600">{r.sessions_count}</p>
                  <p className="text-xs text-gray-400">✓ {r.completed_sessions}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Most Active Students */}
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-purple-500" />
            <h3 className="font-semibold text-gray-800">{isAr ? 'أكثر الطلاب مشاركة' : 'Most Active Students'}</h3>
          </div>
          <div className="space-y-3">
            {(data?.topStudents || []).slice(0, 5).map((s: any, i: number) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center ${i === 0 ? 'bg-amber-100 text-amber-700' : 'bg-gray-50 text-gray-500'}`}>{i + 1}</span>
                  <div>
                    <p className="text-sm text-gray-800 font-medium truncate max-w-[120px]">{s.name}</p>
                    <p className="text-xs text-gray-400 truncate max-w-[120px]">{s.email}</p>
                  </div>
                </div>
                <div className="text-end">
                  <p className="text-xs text-gray-600">{s.recitations} تلاوات</p>
                  <p className="text-xs text-gray-400">{s.bookings} جلسات</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Top Contributors */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <div className="flex items-center gap-2 mb-4">
          <Star className="w-5 h-5 text-amber-500" />
          <h3 className="font-semibold text-gray-800">{isAr ? 'أكثر المقرئين مساهمة' : 'Top Contributors Overall'}</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100">
                {[isAr ? 'الترتيب' : 'Rank', isAr ? 'المقرئ' : 'Reader', isAr ? 'المراجعات' : 'Reviews', isAr ? 'الجلسات' : 'Sessions', isAr ? 'المجموع' : 'Total'].map(h => (
                  <th key={h} className="pb-3 text-gray-500 font-medium text-start">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {(data?.topContributors || []).slice(0, 10).map((r: any, i: number) => (
                <tr key={i} className="hover:bg-gray-50">
                  <td className="py-3 pe-4">
                    <span className={`w-7 h-7 rounded-full text-xs font-bold inline-flex items-center justify-center ${i === 0 ? 'bg-amber-100 text-amber-700' : i === 1 ? 'bg-gray-200 text-gray-600' : i === 2 ? 'bg-orange-100 text-orange-600' : 'bg-gray-100 text-gray-500'}`}>{i + 1}</span>
                  </td>
                  <td className="py-3 pe-4 font-medium text-gray-800">{r.name}</td>
                  <td className="py-3 pe-4 text-blue-600 font-semibold">{r.reviews}</td>
                  <td className="py-3 pe-4 text-purple-600 font-semibold">{r.sessions}</td>
                  <td className="py-3 font-bold text-[#0B3D2E] text-base">{r.total_contribution}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
