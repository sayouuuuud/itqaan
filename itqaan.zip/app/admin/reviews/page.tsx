"use client"

import { useState, useEffect, useCallback } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Star, Loader2, Filter } from "lucide-react"

const VERDICT_MAP: Record<string, { label: string; color: string }> = {
    mastered: { label: 'متقن', color: 'bg-emerald-100 text-emerald-700' },
    needs_session: { label: 'يحتاج جلسة', color: 'bg-amber-100 text-amber-700' },
    needs_improvement: { label: 'يحتاج تحسين', color: 'bg-orange-100 text-orange-700' },
    re_record: { label: 'إعادة تسجيل', color: 'bg-red-100 text-red-700' },
}

export default function AdminReviewsPage() {
    const { t } = useI18n()

    const [reviews, setReviews] = useState<any[]>([])
    const [loading, setLoading] = useState(true)
    const [total, setTotal] = useState(0)
    const [page, setPage] = useState(1)
    const [filterVerdict, setFilterVerdict] = useState('')

    const fetchReviews = useCallback(async () => {
        setLoading(true)
        try {
            const params = new URLSearchParams({ page: String(page) })
            if (filterVerdict) params.set('verdict', filterVerdict)
            const res = await fetch(`/api/admin/reviews?${params}`)
            if (res.ok) {
                const data = await res.json()
                setReviews(data.reviews)
                setTotal(data.total)
            }
        } finally {
            setLoading(false)
        }
    }, [page, filterVerdict])

    useEffect(() => { fetchReviews() }, [fetchReviews])

    const totalPages = Math.ceil(total / 20)

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-foreground">المراجعات</h1>
                <p className="text-sm text-muted-foreground mt-1">سجل كامل بجميع مراجعات القراء للتلاوات</p>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3">
                <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-muted-foreground" />
                    <select
                        className="h-10 rounded-xl border border-border bg-card px-3 text-sm"
                        value={filterVerdict}
                        onChange={e => { setFilterVerdict(e.target.value); setPage(1) }}
                    >
                        <option value="">كل القرارات</option>
                        {Object.entries(VERDICT_MAP).map(([v, m]) => (
                            <option key={v} value={v}>{m.label}</option>
                        ))}
                    </select>
                </div>
            </div>

            {/* Table */}
            <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
                <div className="p-5 border-b border-border/50 bg-muted/30">
                    <h3 className="font-bold text-foreground">
                        المراجعات <span className="text-muted-foreground font-normal text-sm">({total})</span>
                    </h3>
                </div>

                {loading ? (
                    <div className="flex justify-center p-16"><Loader2 className="w-7 h-7 animate-spin text-primary" /></div>
                ) : reviews.length === 0 ? (
                    <div className="p-12 text-center text-muted-foreground">لا توجد مراجعات</div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b border-border bg-muted/20 text-muted-foreground">
                                    <th className="text-right py-3 px-4 font-medium">الطالب</th>
                                    <th className="text-right py-3 px-4 font-medium">المقرئ</th>
                                    <th className="text-right py-3 px-4 font-medium">القرار</th>
                                    <th className="text-right py-3 px-4 font-medium">التجويد</th>
                                    <th className="text-right py-3 px-4 font-medium">النطق</th>
                                    <th className="text-right py-3 px-4 font-medium">الطلاقة</th>
                                    <th className="text-right py-3 px-4 font-medium">الإجمالي</th>
                                    <th className="text-right py-3 px-4 font-medium">التفاصيل</th>
                                    <th className="text-right py-3 px-4 font-medium">التاريخ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reviews.map(r => {
                                    const verdict = VERDICT_MAP[r.verdict] || { label: r.verdict, color: 'bg-muted text-muted-foreground' }
                                    return (
                                        <tr key={r.id} className="border-b border-border/50 hover:bg-muted/20 transition-colors">
                                            <td className="py-3 px-4 font-medium text-foreground">{r.student_name}</td>
                                            <td className="py-3 px-4 text-muted-foreground">{r.reader_name}</td>
                                            <td className="py-3 px-4">
                                                <span className={`text-xs font-bold px-2 py-1 rounded-full ${verdict.color}`}>{verdict.label}</span>
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <span className="text-sm font-bold">{r.tajweed_score ?? '—'}</span>
                                                {r.tajweed_score && <span className="text-muted-foreground text-xs">/10</span>}
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <span className="text-sm font-bold">{r.pronunciation_score ?? '—'}</span>
                                                {r.pronunciation_score && <span className="text-muted-foreground text-xs">/10</span>}
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                <span className="text-sm font-bold">{r.fluency_score ?? '—'}</span>
                                                {r.fluency_score && <span className="text-muted-foreground text-xs">/10</span>}
                                            </td>
                                            <td className="py-3 px-4 text-center">
                                                {r.overall_score ? (
                                                    <span className="text-sm font-bold text-primary">{Number(r.overall_score).toFixed(1)}</span>
                                                ) : <span className="text-muted-foreground">—</span>}
                                            </td>
                                            <td className="py-3 px-4 max-w-[150px]">
                                                <p className="text-xs text-muted-foreground truncate">{r.detailed_feedback || r.areas_for_improvement || '—'}</p>
                                            </td>
                                            <td className="py-3 px-4 text-xs text-muted-foreground whitespace-nowrap">
                                                {new Date(r.created_at).toLocaleDateString('ar-SA')}
                                            </td>
                                        </tr>
                                    )
                                })}
                            </tbody>
                        </table>
                    </div>
                )}

                {totalPages > 1 && (
                    <div className="flex items-center justify-between p-4 border-t border-border/50">
                        <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage(p => p - 1)}>السابق</Button>
                        <span className="text-sm text-muted-foreground">صفحة {page} من {totalPages}</span>
                        <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>التالي</Button>
                    </div>
                )}
            </div>
        </div>
    )
}
