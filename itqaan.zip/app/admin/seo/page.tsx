'use client'

import { useState, useEffect } from 'react'
import { Globe, Save, Eye, Search, ChevronRight, Loader2, CheckCircle } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useI18n } from '@/lib/i18n/context'

export default function AdminSeoPage() {
    const { t } = useI18n()
    const isAr = t.locale === 'ar'

    const [settings, setSettings] = useState({
        seo_site_title: '',
        seo_site_description: '',
        seo_keywords: '',
        seo_og_image: '',
        seo_robots: 'index, follow',
        seo_google_verification: '',
        seo_twitter_site: '',
        seo_canonical_base: '',
    })
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)
    const [saved, setSaved] = useState(false)

    useEffect(() => {
        fetch('/api/admin/seo').then(r => r.json()).then(data => {
            if (data.settings) setSettings(prev => ({ ...prev, ...data.settings }))
            setLoading(false)
        })
    }, [])

    const handleSave = async () => {
        setSaving(true)
        try {
            await fetch('/api/admin/seo', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ settings })
            })
            setSaved(true)
            setTimeout(() => setSaved(false), 3000)
        } finally { setSaving(false) }
    }

    const previewTitle = settings.seo_site_title || 'إتقان الفاتحة'
    const previewDesc = settings.seo_site_description || ''
    const previewUrl = settings.seo_canonical_base || 'https://itqaan.com'

    if (loading) return <div className="flex justify-center p-20"><Loader2 className="w-8 h-8 animate-spin text-[#0B3D2E]" /></div>

    return (
        <div className="p-6 max-w-5xl mx-auto space-y-6" dir={isAr ? 'rtl' : 'ltr'}>
            {/* Header */}
            <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <Globe className="w-8 h-8 text-[#0B3D2E]" />
                    <div>
                        <h1 className="text-2xl font-bold text-gray-900">{isAr ? 'إعدادات SEO' : 'SEO Settings'}</h1>
                        <p className="text-gray-500 text-sm">{isAr ? 'تحكم في ظهور الموقع في محركات البحث' : 'Control how your site appears in search engines'}</p>
                    </div>
                </div>
                <Button onClick={handleSave} disabled={saving} className="bg-[#0B3D2E] hover:bg-[#0B3D2E]/90 text-white gap-2">
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <CheckCircle className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                    {saved ? (isAr ? 'تم الحفظ' : 'Saved!') : (isAr ? 'حفظ' : 'Save')}
                </Button>
            </div>

            {/* Google Preview */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                <div className="flex items-center gap-2 mb-4 text-gray-700 font-semibold">
                    <Eye className="w-5 h-5" />
                    {isAr ? 'معاينة في Google' : 'Google Preview'}
                </div>
                <div className="border border-gray-200 rounded-lg p-4 bg-gray-50 max-w-2xl">
                    <p className="text-xs text-green-700 mb-1 font-mono">{previewUrl}</p>
                    <p className="text-blue-700 text-lg font-medium hover:underline cursor-pointer line-clamp-1">{previewTitle}</p>
                    <p className="text-gray-600 text-sm line-clamp-2 mt-1">{previewDesc}</p>
                </div>
            </div>

            {/* Main SEO Settings */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
                <h2 className="font-semibold text-gray-800 text-lg border-b pb-3">{isAr ? 'الإعدادات الأساسية' : 'Basic Settings'}</h2>

                <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">{isAr ? 'عنوان الموقع (title)' : 'Site Title'}</Label>
                    <Input value={settings.seo_site_title} onChange={e => setSettings(p => ({ ...p, seo_site_title: e.target.value }))} placeholder="إتقان الفاتحة | منصة تعلم القرآن" className="max-w-xl" />
                    <p className="text-xs text-gray-400">{settings.seo_site_title.length}/60 {isAr ? 'حرف (المثالي 50-60)' : 'chars (ideal 50-60)'}</p>
                </div>

                <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">{isAr ? 'وصف الموقع (description)' : 'Meta Description'}</Label>
                    <textarea
                        value={settings.seo_site_description}
                        onChange={e => setSettings(p => ({ ...p, seo_site_description: e.target.value }))}
                        rows={3}
                        className="w-full max-w-xl border border-gray-200 rounded-lg p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-[#0B3D2E]/30"
                        placeholder="وصف الموقع..."
                    />
                    <p className="text-xs text-gray-400">{settings.seo_site_description.length}/160 {isAr ? 'حرف (المثالي 140-160)' : 'chars (ideal 140-160)'}</p>
                </div>

                <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">{isAr ? 'الكلمات المفتاحية' : 'Keywords'}</Label>
                    <Input value={settings.seo_keywords} onChange={e => setSettings(p => ({ ...p, seo_keywords: e.target.value }))} placeholder="تجويد, قرآن, فاتحة, ..." className="max-w-xl" />
                </div>

                <div className="space-y-2">
                    <Label className="text-sm font-medium text-gray-700">{isAr ? 'رابط الصورة OG Image' : 'OG Image URL'}</Label>
                    <Input value={settings.seo_og_image} onChange={e => setSettings(p => ({ ...p, seo_og_image: e.target.value }))} placeholder="https://..." className="max-w-xl" />
                    <p className="text-xs text-gray-400">{isAr ? 'الحجم المثالي: 1200×630 بكسل' : 'Ideal size: 1200×630px'}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-4 border-t">
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">{isAr ? 'الرابط الأساسي للموقع' : 'Canonical Base URL'}</Label>
                        <Input value={settings.seo_canonical_base} onChange={e => setSettings(p => ({ ...p, seo_canonical_base: e.target.value }))} placeholder="https://itqaan.com" />
                    </div>
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Robots</Label>
                        <select
                            value={settings.seo_robots}
                            onChange={e => setSettings(p => ({ ...p, seo_robots: e.target.value }))}
                            className="w-full border border-gray-200 rounded-lg p-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#0B3D2E]/30"
                        >
                            <option value="index, follow">index, follow (recommended)</option>
                            <option value="noindex, follow">noindex, follow</option>
                            <option value="index, nofollow">index, nofollow</option>
                            <option value="noindex, nofollow">noindex, nofollow</option>
                        </select>
                    </div>
                </div>
            </div>

            {/* Verification + Social */}
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 space-y-5">
                <h2 className="font-semibold text-gray-800 text-lg border-b pb-3">{isAr ? 'التحقق والشبكات الاجتماعية' : 'Verification & Social'}</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Google Search Console Verification</Label>
                        <Input value={settings.seo_google_verification} onChange={e => setSettings(p => ({ ...p, seo_google_verification: e.target.value }))} placeholder="google-site-verification=..." />
                    </div>
                    <div className="space-y-2">
                        <Label className="text-sm font-medium text-gray-700">Twitter / X Account</Label>
                        <Input value={settings.seo_twitter_site} onChange={e => setSettings(p => ({ ...p, seo_twitter_site: e.target.value }))} placeholder="@username" />
                    </div>
                </div>
            </div>

            {/* JSON-LD Schema info */}
            <div className="bg-blue-50 rounded-xl border border-blue-200 p-5">
                <div className="flex gap-3">
                    <ChevronRight className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                        <p className="font-semibold text-blue-800">{isAr ? 'JSON-LD Structured Data مُفعّل تلقائيًا' : 'JSON-LD Structured Data is auto-enabled'}</p>
                        <p className="text-blue-700 text-sm mt-1">
                            {isAr
                                ? 'تم إضافة Schema.org markup تلقائيًا لكل صفحة: Organization للرئيسية، WebSite + SearchAction للموقع، BreadcrumbList لجميع الصفحات.'
                                : 'Schema.org markup is automatically added to every page: Organization for homepage, WebSite + SearchAction, BreadcrumbList for all pages.'}
                        </p>
                    </div>
                </div>
            </div>
        </div>
    )
}
