"use client"

import { useState, useEffect } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Save, Mail, Loader2, CheckCircle, Info, ChevronDown } from "lucide-react"

type EmailTemplate = {
    template_key: string
    template_name_ar: string
    template_name_en: string
    subject_ar: string
    subject_en: string
    body_ar: string
    body_en: string
    variables: string[]
    is_active: boolean
}

export default function EmailTemplatesPage() {
    const { t } = useI18n()
    const isAr = t.locale === "ar"

    const [templates, setTemplates] = useState<EmailTemplate[]>([])
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)
    const [saveSuccess, setSaveSuccess] = useState<string | null>(null)
    const [expandedId, setExpandedId] = useState<string | null>(null)

    useEffect(() => {
        async function fetchTemplates() {
            try {
                const res = await fetch("/api/admin/email-templates")
                if (res.ok) {
                    const data = await res.json()
                    setTemplates(data.templates || [])
                }
            } catch (err) {
                console.error(err)
            } finally {
                setLoading(false)
            }
        }
        fetchTemplates()
    }, [])

    const handleUpdate = (templateKey: string, field: keyof EmailTemplate, value: any) => {
        setTemplates(prev =>
            prev.map(t => t.template_key === templateKey ? { ...t, [field]: value } : t)
        )
    }

    const handleSave = async (template: EmailTemplate) => {
        setSaving(true)
        try {
            const res = await fetch("/api/admin/email-templates", {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(template)
            })

            if (res.ok) {
                setSaveSuccess(template.template_key)
                setTimeout(() => setSaveSuccess(null), 3000)
            } else {
                alert("حدث خطأ أثناء حفظ القالب")
            }
        } catch {
            alert("تعذر الاتصال بالخادم")
        } finally {
            setSaving(false)
        }
    }

    if (loading) {
        return (
            <div className="flex justify-center p-20">
                <Loader2 className="w-8 h-8 animate-spin text-[#0B3D2E]" />
            </div>
        )
    }

    return (
        <div className="space-y-6 max-w-4xl">
            <div>
                <h1 className="text-2xl font-bold text-slate-800">{isAr ? "قوالب البريد الإلكتروني" : "Email Templates"}</h1>
                <p className="text-sm text-slate-500 mt-1">{isAr ? "التحكم في صياغة ورسائل البريد التلقائية" : "Manage automated email contents"}</p>
            </div>

            <div className="bg-[#0B3D2E]/5 border border-[#0B3D2E]/10 rounded-xl p-4 flex gap-3 text-sm text-[#0B3D2E]">
                <Info className="w-5 h-5 shrink-0" />
                <p>
                    {isAr
                        ? "استخدم الأقواس المزدوجة للمتغيرات الديناميكية مثل {{studentName}} لطباعة اسم الطالب تلقائياً. تأكد من عدم العبث بها."
                        : "Use double curly brackets for dynamic variables like {{studentName}} to auto-fill the user's name."}
                </p>
            </div>

            <div className="space-y-4">
                {templates.map((template) => {
                    const isExpanded = expandedId === template.template_key

                    return (
                        <Card key={template.template_key} className={`border-slate-200 transition-all shadow-sm overflow-hidden ${isExpanded ? "ring-1 ring-[#0B3D2E]/20" : "hover:border-slate-300"}`}>
                            {/* Header / Summary */}
                            <div
                                className="p-5 flex items-center justify-between cursor-pointer select-none bg-white hover:bg-slate-50 transition-colors"
                                onClick={() => setExpandedId(isExpanded ? null : template.template_key)}
                            >
                                <div className="flex items-center gap-4">
                                    <div className={`p-2.5 rounded-xl ${template.is_active ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                                        <Mail className="w-5 h-5" />
                                    </div>
                                    <div>
                                        <h3 className="font-bold text-slate-800">{isAr ? template.template_name_ar : template.template_name_en}</h3>
                                        <p className="text-xs text-slate-500 font-medium mt-1 dir-ltr opacity-70 border bg-slate-100 inline-block px-2 rounded">{template.template_key}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4">
                                    <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                                        <Switch
                                            checked={template.is_active}
                                            onCheckedChange={(c) => handleUpdate(template.template_key, "is_active", c)}
                                        />
                                        <span className="text-xs font-bold text-slate-500">{template.is_active ? (isAr ? "مُفعل" : "Active") : (isAr ? "معطل" : "Inactive")}</span>
                                    </div>
                                    <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${isExpanded ? "rotate-180" : ""}`} />
                                </div>
                            </div>

                            {/* Editor */}
                            {isExpanded && (
                                <div className="border-t border-slate-100 bg-slate-50/50 p-6 space-y-6">

                                    {/* Subject */}
                                    <div className="space-y-4">
                                        <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                                            {isAr ? "عنوان الرسالة (Subject)" : "Email Subject"}
                                        </h4>
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <Label className="text-xs text-slate-500 mb-1.5 block">{isAr ? "العربي" : "Arabic"}</Label>
                                                <Input
                                                    value={template.subject_ar}
                                                    onChange={e => handleUpdate(template.template_key, "subject_ar", e.target.value)}
                                                    className="bg-white border-slate-200"
                                                />
                                            </div>
                                            <div dir="ltr">
                                                <Label className="text-xs text-slate-500 mb-1.5 block text-left">English</Label>
                                                <Input
                                                    value={template.subject_en || template.subject_ar}
                                                    onChange={e => handleUpdate(template.template_key, "subject_en", e.target.value)}
                                                    className="bg-white border-slate-200"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    <Separator className="bg-slate-200" />

                                    {/* Body */}
                                    <div className="space-y-4">
                                        <div className="flex justify-between items-end">
                                            <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                                                {isAr ? "محتوى الرسالة (Body)" : "Email Body"}
                                            </h4>
                                            {template.variables && typeof template.variables === 'string' && JSON.parse(template.variables).length > 0 && (
                                                <div className="text-xs text-slate-500 flex items-center gap-2">
                                                    <span>{isAr ? "المتغيرات المتاحة:" : "Available variables:"}</span>
                                                    <div className="flex gap-1">
                                                        {JSON.parse(template.variables).map((v: string) => (
                                                            <span key={v} className="bg-[#0B3D2E]/10 text-[#0B3D2E] px-1.5 py-0.5 rounded dir-ltr inline-block font-mono">
                                                                {`{{${v}}}`}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </div>

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div>
                                                <Label className="text-xs text-slate-500 mb-1.5 block">{isAr ? "العربي" : "Arabic"}</Label>
                                                <Textarea
                                                    value={template.body_ar}
                                                    onChange={e => handleUpdate(template.template_key, "body_ar", e.target.value)}
                                                    className="h-48 bg-white border-slate-200 resize-none font-mono text-sm"
                                                />
                                            </div>
                                            <div dir="ltr">
                                                <Label className="text-xs text-slate-500 mb-1.5 block text-left">English</Label>
                                                <Textarea
                                                    value={template.body_en || template.body_ar}
                                                    onChange={e => handleUpdate(template.template_key, "body_en", e.target.value)}
                                                    className="h-48 bg-white border-slate-200 resize-none font-mono text-sm"
                                                />
                                            </div>
                                        </div>
                                    </div>

                                    {/* Actions */}
                                    <div className="flex justify-end pt-2 items-center gap-4">
                                        {saveSuccess === template.template_key && (
                                            <span className="text-sm font-bold text-emerald-600 flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100">
                                                <CheckCircle className="w-4 h-4" />
                                                {isAr ? "تم החفظ" : "Saved"}
                                            </span>
                                        )}
                                        <Button
                                            onClick={() => handleSave(template)}
                                            disabled={saving}
                                            className="bg-[#0B3D2E] hover:bg-[#0A3528] text-white px-6 font-bold"
                                        >
                                            {saving ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : <Save className="w-4 h-4 ml-2 rtl:mr-2 rtl:ml-0" />}
                                            {isAr ? "حفظ התعالت" : "Save Changes"}
                                        </Button>
                                    </div>
                                </div>
                            )}
                        </Card>
                    )
                })}
            </div>
        </div>
    )
}
