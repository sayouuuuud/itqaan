"use client"

import { useState, useEffect } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"
import { Save, Mail, HardDrive, Settings2, CheckCircle, Shield, Loader2, User, Wrench, Database, Trash, RotateCw } from "lucide-react"
import { AvatarUpload } from "@/components/avatar-upload"

export default function AdminSettingsPage() {
  const { t } = useI18n()
  const isAr = t.locale === "ar"

  const [settings, setSettings] = useState<Record<string, any>>({
    // Email
    smtp_host: "smtp.gmail.com",
    smtp_port: "587",
    smtp_user: "",
    smtp_pass: "",
    smtp_tls: true,
    // Storage
    storage_provider: "cloudinary",
    cloud_name: "",
    cloud_api_key: "",
    max_file_size_mb: 20,
    // Workflow
    show_qualification_field: true,
    show_years_of_experience: true,
    reader_attachment_required: false,
    certificate_mandatory_for_mastered: false,
    certificate_pdf_required: false,
    show_certificate_section: true,
    session_duration_minutes: 30,
    max_daily_sessions_per_reader: 5,
    resend_email_on_result_update: true,
    // Security
    two_factor_auth: false,
    activity_logging: true,
    limit_login_attempts: true,
  })


  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  // Profile settings state
  const [profile, setProfile] = useState({ name: "", email: "", password: "", avatar_url: "" })
  const [profileSaving, setProfileSaving] = useState(false)

  // Maintenance state
  const [maintenanceLoading, setMaintenanceLoading] = useState<string | null>(null)

  useEffect(() => {
    async function loadData() {
      try {
        // Load Settings
        const settingsRes = await fetch("/api/admin/settings")
        if (settingsRes.ok) {
          const data = await settingsRes.json()
          if (data.settings && Object.keys(data.settings).length > 0) {
            setSettings(prev => ({ ...prev, ...data.settings }))
          }
        }

        // Load Profile
        const profileRes = await fetch("/api/admin/profile")
        if (profileRes.ok) {
          const data = await profileRes.json()
          if (data.user) {
            setProfile(prev => ({ ...prev, name: data.user.name, email: data.user.email, avatar_url: data.user.avatar_url || "" }))
          }
        }
      } catch (err) {
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  const handleChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch("/api/admin/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings })
      })

      if (res.ok) {
        setShowSuccess(true)
        setTimeout(() => setShowSuccess(false), 3000)
        window.scrollTo({ top: 0, behavior: "smooth" })
      } else {
        alert("حدث خطأ أثناء حفظ الإعدادات")
      }
    } catch {
      alert("تعذر الاتصال بالخادم")
    } finally {
      setSaving(false)
    }
  }

  const handleProfileSave = async () => {
    setProfileSaving(true)
    try {
      const res = await fetch("/api/admin/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile)
      })
      if (res.ok) {
        alert(isAr ? "تم تحديث الملف الشخصي بنجاح" : "Profile updated successfully")
        setProfile({ ...profile, password: "" })
      } else {
        const data = await res.json()
        alert(data.error || "Error")
      }
    } catch {
      alert("Error")
    } finally {
      setProfileSaving(false)
    }
  }

  const handleMaintenance = async (action: string) => {
    setMaintenanceLoading(action)
    try {
      const res = await fetch("/api/admin/maintenance", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action })
      })
      const data = await res.json()
      alert(data.message || data.error)
    } catch {
      alert("Error")
    } finally {
      setMaintenanceLoading(null)
    }
  }

  if (loading) {
    return (
      <div className="flex justify-center p-20">
        <Loader2 className="w-8 h-8 animate-spin text-[#0B3D2E]" />
      </div>
    )
  }

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">{t.admin.settings || (isAr ? "إعدادات المنصة" : "Platform Settings")}</h1>
        <p className="text-sm text-slate-500 mt-1">{isAr ? "التحكم في المتغيرات العامة للنظام" : "Control general system variables"}</p>
      </div>

      {showSuccess && (
        <div className="flex items-center gap-2 p-4 bg-emerald-50 text-emerald-700 rounded-xl text-sm font-bold border border-emerald-200 shadow-sm transition-all duration-300">
          <CheckCircle className="w-5 h-5 flex-shrink-0" />
          {isAr ? "تم حفظ الإعدادات بنجاح" : "Settings saved successfully"}
        </div>
      )}

      {/* General Platform Controls */}
      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Settings2 className="w-5 h-5 text-[#0B3D2E]" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "إعدادات الطلاب والمقرئين" : "Student & Reader Settings"}</CardTitle>
          </div>
          <CardDescription>{isAr ? "التحكم في الحقول والمتطلبات الخاصة بالمنصة" : "Control platform specific fields and requirements"}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5 pt-6">
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "إظهار حقل المؤهلات للمقرئين" : "Show Qualifications Field"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "عرض حقل إضافي للمقرئ عند التسجيل لإدخال المؤهل العلمي" : "Show an extra field for readers during registration"}</p>
            </div>
            <Switch
              checked={!!settings.show_qualification_field}
              onCheckedChange={(c) => handleChange("show_qualification_field", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "إلزامية الشهادة للطالب المتقن" : "Mandatory Certificate"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "إجبار الطالب الحاصل على درجة الإتقان على تعبئة بيانات الشهادة" : "Force mastered students to fill certificate details"}</p>
            </div>
            <Switch
              checked={!!settings.certificate_mandatory_for_mastered}
              onCheckedChange={(c) => handleChange("certificate_mandatory_for_mastered", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="p-3">
            <Label htmlFor="session_duration" className="text-sm font-bold text-slate-800">{isAr ? "مدة الجلسة الافتراضية (بالدقائق)" : "Default Session Duration (mins)"}</Label>
            <p className="text-xs text-slate-500 mt-1 mb-3">{isAr ? "تحديد وقت حجز الجلسة الواحدة الافتراضي" : "Set default time per booking"}</p>
            <select
              id="session_duration"
              value={settings.session_duration_minutes}
              onChange={(e) => handleChange("session_duration_minutes", Number(e.target.value))}
              className="w-full sm:w-64 h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-medium focus:ring-2 focus:ring-[#0B3D2E]/20 focus:border-[#0B3D2E] outline-none"
            >
              <option value={15}>15 {isAr ? "دقيقة" : "mins"}</option>
              <option value={20}>20 {isAr ? "دقيقة" : "mins"}</option>
              <option value={30}>30 {isAr ? "دقيقة" : "mins"}</option>
              <option value={45}>45 {isAr ? "دقيقة" : "mins"}</option>
              <option value={60}>60 {isAr ? "دقيقة" : "mins"}</option>
            </select>
          </div>
          <Separator className="bg-slate-100" />
          <div className="p-3">
            <Label htmlFor="max_daily_sessions" className="text-sm font-bold text-slate-800">{isAr ? "الحد الأقصى للجلسات اليومية للمقرئ" : "Max Daily Sessions per Reader"}</Label>
            <p className="text-xs text-slate-500 mt-1 mb-3">{isAr ? "عدد الجلسات الأقصى التي يمكن للمقرئ استقبالها خلال اليوم الواحد" : "Maximum sessions a reader can receive in one day"}</p>
            <Input
              id="max_daily_sessions"
              type="number"
              min={1}
              max={20}
              value={settings.max_daily_sessions_per_reader ?? 5}
              onChange={e => handleChange("max_daily_sessions_per_reader", Number(e.target.value))}
              className="w-32 bg-slate-50"
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "إظهار قسم إصدار الشهادة" : "Show Certificate Section"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "تفعيل أو إخفاء قسم الشهادة لدى الطلاب المتقنين" : "Show or hide the certificate section for mastered students"}</p>
            </div>
            <Switch
              checked={settings.show_certificate_section !== false}
              onCheckedChange={(c) => handleChange("show_certificate_section", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "تفعيل حقل سنوات الخبرة للمقرئين" : "Enable Years of Experience Field"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "عرض حقل سنوات الخبرة في نموذج تسجيل المقرئ" : "Display years of experience field in reader registration form"}</p>
            </div>
            <Switch
              checked={!!settings.show_years_of_experience}
              onCheckedChange={(c) => handleChange("show_years_of_experience", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "رفع مرفق الشهادة إلزامي للمقرئين" : "Require Certificate Attachment for Readers"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "إلزام المقرئ برفع صورة الشهادة عند التسجيل" : "Require readers to upload a certificate document during registration"}</p>
            </div>
            <Switch
              checked={!!settings.reader_attachment_required}
              onCheckedChange={(c) => handleChange("reader_attachment_required", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "إعادة إرسال البريد عند تعديل النتيجة" : "Resend Email on Result Update"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "إرسال إشعار بريدي للطالب في حال تعديل نتيجة التلاوة من قبل الأدمن" : "Email student when admin updates recitation verdict"}</p>
            </div>
            <Switch
              checked={settings.resend_email_on_result_update !== false}
              onCheckedChange={(c) => handleChange("resend_email_on_result_update", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 transition-colors">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "رفع PDF الشهادة مطلوب" : "Require Certificate PDF Upload"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "إلزام الطالب برفع PDF شهادته لاستكمال قسم الإتقان" : "Require students to upload their certificate PDF to complete mastery"}</p>
            </div>
            <Switch
              checked={!!settings.certificate_pdf_required}
              onCheckedChange={(c) => handleChange("certificate_pdf_required", c)}
            />
          </div>
        </CardContent>
      </Card>


      {/* Email SMTP */}
      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Mail className="w-5 h-5 text-[#0B3D2E]" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "إعدادات البريد الإلكتروني (SMTP)" : "Email Settings (SMTP)"}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="smtp-host" className="font-bold text-slate-700">SMTP Host</Label>
              <Input
                id="smtp-host"
                value={settings.smtp_host}
                onChange={e => handleChange("smtp_host", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp-port" className="font-bold text-slate-700">SMTP Port</Label>
              <Input
                id="smtp-port"
                value={settings.smtp_port}
                onChange={e => handleChange("smtp_port", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp-user" className="font-bold text-slate-700">{isAr ? "اسم المستخدم" : "Username"}</Label>
              <Input
                id="smtp-user"
                value={settings.smtp_user}
                onChange={e => handleChange("smtp_user", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="smtp-pass" className="font-bold text-slate-700">{isAr ? "كلمة المرور" : "Password"}</Label>
              <Input
                id="smtp-pass"
                type="password"
                value={settings.smtp_pass}
                onChange={e => handleChange("smtp_pass", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Switch
              id="smtp-tls"
              checked={!!settings.smtp_tls}
              onCheckedChange={(c) => handleChange("smtp_tls", c)}
            />
            <Label htmlFor="smtp-tls" className="font-bold text-slate-700">{isAr ? "استخدام TLS" : "Use TLS"}</Label>
          </div>
        </CardContent>
      </Card>

      {/* Storage Settings */}
      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-[#0B3D2E]" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "إعدادات التخزين" : "Storage Settings"}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          <div className="space-y-2">
            <Label htmlFor="storage-provider" className="font-bold text-slate-700">{isAr ? "مزود التخزين" : "Storage Provider"}</Label>
            <select
              id="storage-provider"
              className="w-full h-10 rounded-md border border-slate-200 bg-white px-3 text-sm focus:ring-[#0B3D2E]"
              value={settings.storage_provider}
              onChange={e => handleChange("storage_provider", e.target.value)}
            >
              <option value="cloudinary">Cloudinary</option>
              <option value="s3">Amazon S3</option>
              <option value="supabase">Supabase Storage</option>
            </select>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="cloud-name" className="font-bold text-slate-700">Cloud Name</Label>
              <Input
                id="cloud-name"
                value={settings.cloud_name}
                onChange={e => handleChange("cloud_name", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="api-key" className="font-bold text-slate-700">API Key</Label>
              <Input
                id="api-key"
                type="password"
                value={settings.api_key}
                onChange={e => handleChange("api_key", e.target.value)}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-[#0B3D2E]" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "إعدادات الأمان والتسجيل" : "Security & Logging"}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-5 pt-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "تفعيل التحقق بخطوتين (2FA)" : "Enable Two-Factor Auth"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "إلزام جميع المستخدمين بالتحقق المزدوج لتسجيل الدخول" : "Enforce 2FA for all users"}</p>
            </div>
            <Switch
              checked={!!settings.two_factor_auth}
              onCheckedChange={c => handleChange("two_factor_auth", c)}
            />
          </div>
          <Separator className="bg-slate-100" />
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-slate-800">{isAr ? "الحد من محاولات الدخول الفاشلة" : "Limit Login Attempts"}</p>
              <p className="text-xs text-slate-500 mt-1">{isAr ? "قفل الحساب مؤقتاً بعد 5 محاولات خاطئة لمنع هجمات التخمين" : "Lock account after 5 failed attempts"}</p>
            </div>
            <Switch
              checked={!!settings.limit_login_attempts}
              onCheckedChange={c => handleChange("limit_login_attempts", c)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Admin Profile Management */}
      <Card className="border-slate-200 shadow-sm overflow-hidden">
        <CardHeader className="bg-slate-50 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-[#0B3D2E]" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "إدارة حساب الأدمن" : "Admin Profile Management"}</CardTitle>
          </div>
          <CardDescription>{isAr ? "تحديث بياناتك الشخصية وكلمة المرور" : "Update your personal details and password"}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          {/* Avatar */}
          <div className="flex items-center gap-5 mb-2">
            <AvatarUpload
              currentUrl={profile.avatar_url}
              name={profile.name}
              size="md"
              onUploaded={async (url) => {
                setProfile(p => ({ ...p, avatar_url: url }))
                await fetch('/api/auth/me', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ avatar_url: url }) })
              }}
            />
            <div>
              <p className="text-sm font-bold text-slate-700">{isAr ? 'الصورة الشخصية' : 'Profile Photo'}</p>
              <p className="text-xs text-slate-500">{isAr ? 'اضغط على الصورة لتغييرها' : 'Click to change photo'}</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div className="space-y-2">
              <Label htmlFor="admin-name" className="font-bold text-slate-700">{isAr ? "الاسم" : "Name"}</Label>
              <Input
                id="admin-name"
                value={profile.name}
                onChange={e => setProfile({ ...profile, name: e.target.value })}
                placeholder={isAr ? "ادخل اسمك الجديد" : "Enter new name"}
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="admin-email" className="font-bold text-slate-700">{isAr ? "البريد الإلكتروني" : "Email"}</Label>
              <Input
                id="admin-email"
                value={profile.email}
                onChange={e => setProfile({ ...profile, email: e.target.value })}
                placeholder={isAr ? "ادخل بريدك الجديد" : "Enter new email"}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label htmlFor="admin-pass" className="font-bold text-slate-700">{isAr ? "كلمة المرور الجديدة" : "New Password"}</Label>
              <Input
                id="admin-pass"
                type="password"
                value={profile.password}
                onChange={e => setProfile({ ...profile, password: e.target.value })}
                placeholder={isAr ? "اتركه فارغاً إذا كنت لا تريد تغييره" : "Leave blank if you don't want to change it"}
                dir="ltr"
                className="bg-slate-50"
              />
            </div>
          </div>
          <div className="flex justify-end pt-2">
            <Button
              onClick={handleProfileSave}
              className="bg-[#D4A843] hover:bg-[#C39732] text-[#0B3D2E] font-bold"
              disabled={profileSaving}
            >
              {profileSaving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
              {isAr ? "تحديث الملف الشخصي" : "Update Profile"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Maintenance & Tools */}
      <Card className="border-slate-200 shadow-sm overflow-hidden bg-rose-50/10">
        <CardHeader className="bg-rose-50/50 border-b border-rose-100">
          <div className="flex items-center gap-2">
            <Wrench className="w-5 h-5 text-rose-600" />
            <CardTitle className="text-base text-slate-800 font-bold">{isAr ? "أدوات الصيانة والنظام" : "Maintenance & System Tools"}</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-4 pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              variant="outline"
              className="flex-1 h-auto py-6 flex flex-col items-center gap-3 border-rose-200 hover:bg-rose-50"
              onClick={() => handleMaintenance("clear-cache")}
              disabled={!!maintenanceLoading}
            >
              {maintenanceLoading === "clear-cache" ? <RotateCw className="w-6 h-6 animate-spin text-rose-600" /> : <Trash className="w-6 h-6 text-rose-600" />}
              <div className="text-center">
                <p className="font-bold text-rose-900 text-sm">{isAr ? "تفريغ ذاكرة الكاش" : "Clear System Cache"}</p>
                <p className="text-[10px] text-rose-600 mt-1">{isAr ? "إعادة تحميل بيانات الصفحة وتحديث الواجهات" : "Force UI and data revalidation"}</p>
              </div>
            </Button>

            <Button
              variant="outline"
              className="flex-1 h-auto py-6 flex flex-col items-center gap-3 border-emerald-200 hover:bg-emerald-50"
              onClick={() => handleMaintenance("backup")}
              disabled={!!maintenanceLoading}
            >
              {maintenanceLoading === "backup" ? <RotateCw className="w-6 h-6 animate-spin text-emerald-600" /> : <Database className="w-6 h-6 text-emerald-600" />}
              <div className="text-center">
                <p className="font-bold text-emerald-900 text-sm">{isAr ? "نسخ احتياطي لقاعدة البيانات" : "Database Backup"}</p>
                <p className="text-[10px] text-emerald-600 mt-1">{isAr ? "تحميل نسخة كاملة من البيانات الحالية" : "Download full snapshot of data"}</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col sm:flex-row justify-end items-center gap-4 pt-4 pb-12 overflow-hidden">
        <div className="bg-amber-50 text-amber-700 text-xs px-4 py-2 rounded-lg font-bold">
          {isAr ? "تلميح: يتم تطبيق هذه الإعدادات على المنصة فور حفظها." : "Hint: Settings take effect immediately upon saving."}
        </div>
        <Button
          onClick={handleSave}
          disabled={saving}
          className="bg-[#0B3D2E] hover:bg-[#0A3528] text-white px-8 py-6 h-auto text-base font-bold shadow-lg w-full sm:w-auto"
        >
          {saving ? <Loader2 className="w-5 h-5 animate-spin ml-2" /> : <Save className="w-5 h-5 ml-2 rtl:mr-2 rtl:ml-0" />}
          {t.save || (isAr ? "حفظ وتطبيق جميع الإعدادات" : "Save & Apply All Settings")}
        </Button>
      </div>
    </div>
  )
}
