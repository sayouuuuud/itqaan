"use client"

import { useState, useEffect } from "react"
import { useI18n } from "@/lib/i18n/context"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Loader2, BarChart3, TrendingUp, Users, Star, CheckCircle, Calendar, Download } from "lucide-react"
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
    ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell, Legend
} from "recharts"

const STATUS_COLORS: Record<string, string> = {
    pending: '#f59e0b', in_review: '#3b82f6', mastered: '#10b981',
    needs_session: '#D4A843', session_booked: '#8b5cf6', rejected: '#ef4444',
}

const STATUS_LABELS: Record<string, string> = {
    pending: 'قيد المراجعة', in_review: 'جاري المراجعة', mastered: 'متقن',
    needs_session: 'يحتاج جلسة', session_booked: 'تم الحجز', rejected: 'مرفوض',
}

export default function AdminStatisticsPage() {
    const { t } = useI18n()

    const [data, setData] = useState<any>(null)
    const [loading, setLoading] = useState(true)
    const [dateFrom, setDateFrom] = useState('')
    const [dateTo, setDateTo] = useState('')

    const fetchStats = async () => {
        setLoading(true)
        try {
            const params = new URLSearchParams()
            if (dateFrom) params.set('dateFrom', dateFrom)
            if (dateTo) params.set('dateTo', dateTo)
            const res = await fetch(`/api/admin/statistics?${params}`)
            if (res.ok) setData(await res.json())
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => { fetchStats() }, [])

    const pieData = data?.byStatus?.map((s: any) => ({
        name: STATUS_LABELS[s.status] || s.status,
        value: parseInt(s.count),
        color: STATUS_COLORS[s.status] || '#94a3b8',
    })) || []

    return (
        <div className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-2xl font-bold text-foreground">الإحصائيات</h1>
                    <p className="text-sm text-muted-foreground mt-1">إحصائيات تفصيلية شاملة عن أداء المنصة</p>
                </div>
            </div>

            {/* Date Filter */}
            <div className="bg-card border border-border rounded-2xl p-4 flex flex-wrap gap-3 items-end">
                <div className="space-y-1">
                    <p className="text-xs text-muted-foreground font-medium">من</p>
                    <Input type="date" className="h-10 w-40" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
                </div>
                <div className="space-y-1">
                    <p className="text-xs text-muted-foreground font-medium">إلى</p>
                    <Input type="date" className="h-10 w-40" value={dateTo} onChange={e => setDateTo(e.target.value)} />
                </div>
                <Button onClick={fetchStats} className="bg-[#0B3D2E] text-white h-10">
                    <BarChart3 className="w-4 h-4 ml-2" /> تطبيق
                </Button>
                {(dateFrom || dateTo) && (
                    <Button variant="ghost" size="sm" className="h-10" onClick={() => { setDateFrom(''); setDateTo(''); }}>
                        مسح
                    </Button>
                )}
            </div>

            {loading ? (
                <div className="flex justify-center p-20"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>
            ) : !data ? (
                <div className="text-center py-12 text-muted-foreground">فشل تحميل البيانات</div>
            ) : (
                <>
                    {/* Overall KPIs */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                        {[
                            { label: 'إجمالي الطلاب', value: data.overall.total_students || 0, icon: Users, color: 'bg-blue-50 text-blue-600' },
                            { label: 'إجمالي التلاوات', value: data.overall.total_recitations || 0, icon: BarChart3, color: 'bg-amber-50 text-amber-600' },
                            { label: 'معدل الإتقان', value: `${data.overall.mastery_rate || 0}%`, icon: TrendingUp, color: 'bg-emerald-50 text-emerald-600' },
                            { label: 'متوسط تقييم الجلسات', value: data.overall.avg_rating ? Number(data.overall.avg_rating).toFixed(1) : '—', icon: Star, color: 'bg-purple-50 text-purple-600' },
                        ].map(s => (
                            <div key={s.label} className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <p className="text-sm text-muted-foreground">{s.label}</p>
                                        <p className="text-2xl font-bold text-foreground mt-1">{s.value}</p>
                                    </div>
                                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${s.color}`}>
                                        <s.icon className="w-5 h-5" />
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Charts Row 1 */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Recitations Over Time */}
                        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm lg:col-span-2">
                            <h3 className="font-bold text-foreground mb-4">التلاوات عبر الوقت</h3>
                            <div className="h-[220px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <BarChart data={data.overTime}>
                                        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                                        <XAxis dataKey="date" tick={{ fontSize: 10 }} />
                                        <YAxis tick={{ fontSize: 10 }} />
                                        <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} />
                                        <Bar dataKey="count" fill="#0B3D2E" radius={[4, 4, 0, 0]} name="التلاوات" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </div>
                        </div>

                        {/* Status Pie */}
                        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                            <h3 className="font-bold text-foreground mb-4">توزيع الحالات</h3>
                            <div className="h-[180px]">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value">
                                            {pieData.map((entry: any, idx: number) => (
                                                <Cell key={idx} fill={entry.color} />
                                            ))}
                                        </Pie>
                                        <Tooltip contentStyle={{ fontSize: '11px' }} />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                            <div className="space-y-1.5 mt-2">
                                {pieData.map((item: any) => (
                                    <div key={item.name} className="flex items-center justify-between text-xs">
                                        <div className="flex items-center gap-1.5">
                                            <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
                                            <span className="text-muted-foreground">{item.name}</span>
                                        </div>
                                        <span className="font-bold text-foreground">{item.value}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Mastery Rate Trend */}
                    <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                        <h3 className="font-bold text-foreground mb-4">معدل الإتقان عبر الأشهر</h3>
                        <div className="h-[200px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <LineChart data={data.masteryRate}>
                                    <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                                    <XAxis dataKey="month" tick={{ fontSize: 10 }} />
                                    <YAxis tick={{ fontSize: 10 }} domain={[0, 100]} />
                                    <Tooltip contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)', borderRadius: '8px', fontSize: '12px' }} formatter={(v: any) => [`${v}%`, 'معدل الإتقان']} />
                                    <Line type="monotone" dataKey="rate" stroke="#D4A843" strokeWidth={2.5} dot={{ fill: '#D4A843', r: 4 }} />
                                </LineChart>
                            </ResponsiveContainer>
                        </div>
                    </div>

                    {/* Top Readers + Gender + City */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Top Readers */}
                        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm lg:col-span-2">
                            <h3 className="font-bold text-foreground mb-4">أداء المقرئين</h3>
                            <div className="space-y-3">
                                {data.topReaders?.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">لا توجد بيانات</p>
                                ) : data.topReaders?.map((r: any, i: number) => (
                                    <div key={r.name} className="flex items-center gap-3">
                                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#0B3D2E] to-[#1A6B4A] flex items-center justify-center text-white text-xs font-bold shrink-0">
                                            {i + 1}
                                        </div>
                                        <span className="text-sm font-medium text-foreground min-w-[120px]">{r.name}</span>
                                        <div className="flex-1 h-5 bg-muted rounded-full overflow-hidden">
                                            <div
                                                className="h-full bg-primary rounded-full"
                                                style={{ width: `${(r.reviews / (Math.max(...data.topReaders.map((x: any) => x.reviews)) || 1)) * 100}%` }}
                                            />
                                        </div>
                                        <span className="text-sm font-bold text-foreground min-w-[30px] text-left">{r.reviews}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Gender + Sessions */}
                        <div className="space-y-4">
                            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                                <h3 className="font-bold text-foreground mb-3 text-sm">توزيع الجنس (طلاب)</h3>
                                {data.gender?.length === 0 ? (
                                    <p className="text-xs text-muted-foreground">لا توجد بيانات</p>
                                ) : (
                                    <div className="space-y-2">
                                        {data.gender?.map((g: any) => (
                                            <div key={g.gender} className="flex items-center justify-between text-sm">
                                                <span className="text-muted-foreground">{g.gender === 'male' ? 'ذكور' : g.gender === 'female' ? 'إناث' : 'غير محدد'}</span>
                                                <span className="font-bold text-foreground">{g.count}</span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>
                            <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                                <h3 className="font-bold text-foreground mb-3 text-sm">إحصائيات الجلسات</h3>
                                {data.sessions ? (
                                    <div className="space-y-2 text-sm">
                                        <div className="flex justify-between"><span className="text-muted-foreground">مكتملة</span><span className="font-bold text-emerald-600">{data.sessions.completed || 0}</span></div>
                                        <div className="flex justify-between"><span className="text-muted-foreground">ملغية</span><span className="font-bold text-red-600">{data.sessions.cancelled || 0}</span></div>
                                        <div className="flex justify-between"><span className="text-muted-foreground">لم يحضر</span><span className="font-bold text-amber-600">{data.sessions.no_show || 0}</span></div>
                                        {data.sessions.avg_duration && (
                                            <div className="flex justify-between"><span className="text-muted-foreground">متوسط المدة</span><span className="font-bold">{data.sessions.avg_duration} د</span></div>
                                        )}
                                    </div>
                                ) : <p className="text-xs text-muted-foreground">لا توجد بيانات</p>}
                            </div>
                        </div>
                    </div>

                    {/* Top Cities */}
                    {data.byCity?.length > 0 && (
                        <div className="bg-card border border-border rounded-2xl p-5 shadow-sm">
                            <h3 className="font-bold text-foreground mb-4">أعلى المدن تسجيلًا</h3>
                            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                                {data.byCity.map((c: any) => (
                                    <div key={c.city} className="text-center p-3 rounded-xl bg-muted/40">
                                        <p className="text-lg font-bold text-foreground">{c.count}</p>
                                        <p className="text-xs text-muted-foreground mt-0.5">{c.city}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    )
}
