"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useI18n } from "@/lib/i18n/context"
import {
    ChevronRight, Mail, Calendar, Clock, Laptop, Globe,
    MessageSquare, Mic, User as UserIcon, Shield,
    TrendingUp, Activity, Loader2, AlertCircle, Phone,
    CheckCircle2, XCircle, Star, BarChart3, Info
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function UserProfilePage({ params }: { params: { id: string } }) {
    const { t } = useI18n()
    const router = useRouter()
    const isAr = t.locale === "ar"
    const [data, setData] = useState<any>(null)
    const [loading, setLoading] = useState(true)
    const [error, setError] = useState<string | null>(null)
    const [activeTab, setActiveTab] = useState("info")

    useEffect(() => {
        async function fetchData() {
            try {
                const res = await fetch(`/api/admin/users/${params.id}`)
                if (!res.ok) throw new Error(t.admin.failedToLoadData)
                const json = await res.json()
                setData(json)
            } catch (err: any) {
                setError(err.message)
            } finally {
                setLoading(false)
            }
        }
        fetchData()
    }, [params.id, t.admin.failedToLoadData])

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
                <Loader2 className="w-10 h-10 animate-spin text-[#0B3D2E]" />
                <p className="text-slate-500 font-medium">{t.loading}</p>
            </div>
        )
    }

    if (error || !data) {
        return (
            <div className="flex flex-col items-center justify-center min-h-[400px] gap-4 text-destructive">
                <AlertCircle className="w-12 h-12" />
                <p className="text-lg font-bold">{error || t.admin.userNotFound}</p>
                <Button onClick={() => router.back()} variant="outline">{t.back}</Button>
            </div>
        )
    }

    const { user, metrics, lastSession } = data

    return (
        <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            {/* Header / Breadcrumbs */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2 text-sm text-slate-500">
                    <button onClick={() => router.push('/admin/users')} className="hover:text-[#0B3D2E] transition-colors">
                        {t.admin.users}
                    </button>
                    <ChevronRight className="w-4 h-4 rtl:rotate-180" />
                    <span className="font-bold text-slate-800">{user.name}</span>
                </div>
                <div className="flex gap-3">
                    <Badge variant={user.is_active ? "default" : "destructive"} className="px-3 py-1">
                        {user.is_active ? t.active : t.blocked}
                    </Badge>
                </div>
            </div>

            {/* Profile Overview Card */}
            <Card className="border-none shadow-xl overflow-hidden bg-white">
                <div className="h-32 bg-[#0B3D2E] relative overflow-hidden">
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent"></div>
                    <div className="absolute -bottom-12 right-8">
                        <div className="w-24 h-24 rounded-3xl bg-white p-1.5 shadow-2xl">
                            <div className="w-full h-full rounded-2xl bg-emerald-50 flex items-center justify-center text-[#0B3D2E] font-black text-4xl border border-emerald-100">
                                {user.avatar_url ? (
                                    <img src={user.avatar_url} alt={user.name} className="w-full h-full object-cover rounded-2xl" />
                                ) : (
                                    user.name.charAt(0)
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                <CardContent className="pt-16 pb-6 px-8">
                    <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
                        <div>
                            <h2 className="text-3xl font-black text-slate-800 mb-1">{user.name}</h2>
                            <div className="flex items-center gap-4 text-slate-500 text-sm font-medium">
                                <span className="flex items-center gap-1.5"><Mail className="w-4 h-4" /> {user.email}</span>
                                {user.phone && <span className="flex items-center gap-1.5"><Phone className="w-4 h-4" /> {user.phone}</span>}
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <Button onClick={() => setActiveTab("chat")} className="bg-[#0B3D2E] hover:bg-[#0A3527] text-white gap-2">
                                <MessageSquare className="w-4 h-4" />
                                {t.admin.messageUser}
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* TABS Navigation */}
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="bg-transparent border-b border-slate-200 rounded-none w-full justify-start h-auto p-0 mb-6 gap-8">
                    <TabsTrigger value="info" className="data-[state=active]:bg-transparent data-[state=active]:border-[#0B3D2E] data-[state=active]:text-[#0B3D2E] rounded-none border-b-2 border-transparent px-2 py-4 text-slate-500 font-bold gap-2">
                        <Info className="w-4 h-4" />
                        {t.admin.basicInfo}
                    </TabsTrigger>
                    <TabsTrigger value="stats" className="data-[state=active]:bg-transparent data-[state=active]:border-[#0B3D2E] data-[state=active]:text-[#0B3D2E] rounded-none border-b-2 border-transparent px-2 py-4 text-slate-500 font-bold gap-2">
                        <BarChart3 className="w-4 h-4" />
                        {t.admin.statistics}
                    </TabsTrigger>
                    <TabsTrigger value="chat" className="data-[state=active]:bg-transparent data-[state=active]:border-[#0B3D2E] data-[state=active]:text-[#0B3D2E] rounded-none border-b-2 border-transparent px-2 py-4 text-slate-500 font-bold gap-2">
                        <MessageSquare className="w-4 h-4" />
                        {t.admin.chat}
                    </TabsTrigger>
                </TabsList>

                {/* INFO TAB */}
                <TabsContent value="info" className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <Card className="border-slate-100 shadow-sm">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t.admin.accountDetails}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                                    <span className="text-slate-600 font-medium">{t.auth.role}</span>
                                    <Badge variant="outline" className="bg-slate-50 capitalize">{user.role === 'student' ? t.student.studentLabel || t.auth.student : t.reader.readerLabel || t.auth.reader}</Badge>
                                </div>
                                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                                    <span className="text-slate-600 font-medium">{t.admin.joinDate}</span>
                                    <span className="text-slate-800 font-bold">{new Date(user.created_at).toLocaleDateString(t.locale === 'ar' ? 'ar-SA' : 'en-US')}</span>
                                </div>
                                <div className="flex justify-between items-center py-2">
                                    <span className="text-slate-600 font-medium">{t.admin.lastLogin}</span>
                                    <span className="text-slate-800 font-bold">{user.last_login_at ? new Date(user.last_login_at).toLocaleString(t.locale === 'ar' ? 'ar-SA' : 'en-US') : "---"}</span>
                                </div>
                            </CardContent>
                        </Card>

                        <Card className="border-slate-100 shadow-sm">
                            <CardHeader className="pb-2">
                                <CardTitle className="text-sm font-bold text-slate-400 uppercase tracking-wider">{t.admin.technicalData}</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                                    <span className="text-slate-600 font-medium flex items-center gap-2"><Globe className="w-4 h-4" /> {t.admin.countryIp}</span>
                                    <span className="text-slate-800 font-bold font-mono">{lastSession?.ip_address || "N/A"}</span>
                                </div>
                                <div className="flex justify-between items-center py-2 border-b border-slate-50">
                                    <span className="text-slate-600 font-medium flex items-center gap-2"><Laptop className="w-4 h-4" /> {t.admin.device}</span>
                                    <span className="text-slate-800 font-bold text-xs max-w-[200px] truncate" title={lastSession?.user_agent}>{lastSession?.user_agent || "N/A"}</span>
                                </div>
                            </CardContent>
                        </Card>
                    </div>
                </TabsContent>

                {/* STATS TAB */}
                <TabsContent value="stats" className="space-y-8">
                    {/* Quick Metrics Cards */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <Card className="border-none shadow-sm bg-blue-50/50">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-sm font-bold text-blue-600/70 mb-1">{t.admin.completedSessions}</p>
                                        <h3 className="text-3xl font-black text-blue-900">{metrics.sessions.completed}</h3>
                                    </div>
                                    <div className="p-2 bg-blue-100 rounded-lg"><CheckCircle2 className="w-5 h-5 text-blue-600" /></div>
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="border-none shadow-sm bg-orange-50/50">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-sm font-bold text-orange-600/70 mb-1">{t.admin.noShows}</p>
                                        <h3 className="text-3xl font-black text-orange-900">{metrics.sessions.noShow}</h3>
                                    </div>
                                    <div className="p-2 bg-orange-100 rounded-lg"><XCircle className="w-5 h-5 text-orange-600" /></div>
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="border-none shadow-sm bg-purple-50/50">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-sm font-bold text-purple-600/70 mb-1">{t.admin.totalRecitations}</p>
                                        <h3 className="text-3xl font-black text-purple-900">{metrics.recitations.monthly}</h3>
                                    </div>
                                    <div className="p-2 bg-purple-100 rounded-lg"><Mic className="w-5 h-5 text-purple-600" /></div>
                                </div>
                            </CardContent>
                        </Card>
                        <Card className="border-none shadow-sm bg-emerald-50/50">
                            <CardContent className="p-6">
                                <div className="flex justify-between items-start">
                                    <div>
                                        <p className="text-sm font-bold text-emerald-600/70 mb-1">{t.admin.rating}</p>
                                        <h3 className="text-3xl font-black text-emerald-900">{metrics.rating.toFixed(1)} <span className="text-sm font-medium opacity-50">/ 5.0</span></h3>
                                    </div>
                                    <div className="p-2 bg-emerald-100 rounded-lg"><Star className="w-5 h-5 text-emerald-600 fill-emerald-600" /></div>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Weekly Performance Placeholder */}
                    <Card className="border-none shadow-md overflow-hidden bg-slate-900 text-white min-h-[300px] flex items-center justify-center relative">
                        <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:14px_24px]"></div>
                        <div className="text-center space-y-4 z-10">
                            <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4 border border-white/20">
                                <TrendingUp className="w-8 h-8 text-emerald-400" />
                            </div>
                            <h4 className="text-xl font-bold">{t.admin.activityChartsComingSoon}</h4>
                            <p className="text-slate-400 max-w-md mx-auto px-6">{t.admin.activityChartsDesc}</p>
                        </div>
                    </Card>
                </TabsContent>

                {/* CHAT TAB */}
                <TabsContent value="chat" className="h-[500px]">
                    <Card className="border-none shadow-lg h-full overflow-hidden">
                        <div className="flex flex-col h-full items-center justify-center bg-slate-50 text-slate-400 gap-4">
                            <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center">
                                <MessageSquare className="w-10 h-10 opacity-30" />
                            </div>
                            <div className="text-center">
                                <h4 className="text-slate-800 font-bold mb-1">{t.admin.chatIntegration}</h4>
                                <p className="text-sm mb-6 max-w-xs">{t.admin.chatIntegrationDesc}</p>
                                <Button onClick={() => router.push(`/admin/conversations`)} variant="outline" className="border-slate-300 font-bold text-slate-700">
                                    {t.admin.openConversationsCenter}
                                </Button>
                            </div>
                        </div>
                    </Card>
                </TabsContent>
            </Tabs>
        </div>
    )
}
