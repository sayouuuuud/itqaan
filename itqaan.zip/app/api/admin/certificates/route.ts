import { NextRequest, NextResponse } from "next/server"
import { getSession, requireRole } from "@/lib/auth"
import { query, queryOne } from "@/lib/db"
import { sendCertificateIssuedEmail } from "@/lib/email"

// GET /api/admin/certificates
export async function GET(req: NextRequest) {
    try {
        const session = await getSession()
        if (!session || !requireRole(session, ["admin"])) {
            return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
        }

        const { searchParams } = new URL(req.url)
        const status = searchParams.get("status") || "pending" // pending, issued, all

        let statusCondition = ""
        if (status === "pending") {
            statusCondition = "AND cd.certificate_issued = false"
        } else if (status === "issued") {
            statusCondition = "AND cd.certificate_issued = true"
        }

        const applications = await query(
            `SELECT cd.*, u.name as student_name, u.email as student_email,
       (SELECT status FROM recitations r WHERE r.student_id = cd.student_id ORDER BY created_at DESC LIMIT 1) as recitation_status
       FROM certificate_data cd
       JOIN users u ON u.id = cd.student_id
       WHERE 1=1 ${statusCondition}
       ORDER BY cd.created_at DESC`
        )

        return NextResponse.json({ applications })
    } catch (error) {
        console.error("Get certificates error:", error)
        return NextResponse.json({ error: "حدث خطأ في الخادم" }, { status: 500 })
    }
}

// PUT /api/admin/certificates/:id/issue
export async function PUT(req: NextRequest) {
    try {
        const session = await getSession()
        if (!session || !requireRole(session, ["admin"])) {
            return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
        }

        const { id, action } = await req.json()

        if (!id || action !== "issue") {
            return NextResponse.json({ error: "طلب غير صحيح" }, { status: 400 })
        }

        // Verify it exists
        const cert = await queryOne<{ student_id: string; certificate_issued: boolean; student_name: string; student_email: string }>(
            `SELECT cd.student_id, cd.certificate_issued, u.name as student_name, u.email as student_email 
       FROM certificate_data cd
       JOIN users u ON u.id = cd.student_id
       WHERE cd.id = $1`,
            [id]
        )

        if (!cert) {
            return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 })
        }

        if (cert.certificate_issued) {
            return NextResponse.json({ error: "تم إصدار الشهادة مسبقاً" }, { status: 400 })
        }

        const certificateUrl = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/c/${cert.student_id}`

        // Update status
        await query(
            `UPDATE certificate_data 
       SET certificate_issued = true, certificate_url = $1, updated_at = NOW()
       WHERE id = $2`,
            [certificateUrl, id]
        )

        // Send email to student
        if (cert.student_email) {
            await sendCertificateIssuedEmail(cert.student_email, cert.student_name, certificateUrl)
        }

        return NextResponse.json({ success: true, certificateUrl })
    } catch (error) {
        console.error("Issue certificate error:", error)
        return NextResponse.json({ error: "حدث خطأ في الخادم" }, { status: 500 })
    }
}
