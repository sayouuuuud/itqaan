import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import { query } from '@/lib/db'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const readerId = searchParams.get('readerId') || ''
  const page = parseInt(searchParams.get('page') || '1')
  const limit = 20
  const offset = (page - 1) * limit

  let conditions: string[] = []
  let params: any[] = []
  let idx = 1

  if (readerId) { conditions.push(`rr.reader_id = $${idx++}`); params.push(readerId) }

  const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : ''

  const q = `
    SELECT
      rr.id, rr.rating, rr.teaching_quality, rr.communication,
      rr.punctuality, rr.helpfulness, rr.feedback_text, rr.would_recommend,
      rr.created_at,
      s.name AS student_name,
      r.name AS reader_name,
      b.scheduled_at AS session_date
    FROM reader_ratings rr
    JOIN users s ON rr.student_id = s.id
    JOIN users r ON rr.reader_id = r.id
    JOIN bookings b ON rr.booking_id = b.id
    ${where}
    ORDER BY rr.created_at DESC
    LIMIT $${idx++} OFFSET $${idx++}
  `
  params.push(limit, offset)

  const countQuery = `SELECT COUNT(*) AS total FROM reader_ratings rr ${where}`

  const avgQuery = `
    SELECT
      r.id AS reader_id, r.name AS reader_name,
      ROUND(AVG(rr.rating), 2) AS avg_rating,
      COUNT(rr.id) AS total_ratings
    FROM reader_ratings rr
    JOIN users r ON rr.reader_id = r.id
    GROUP BY r.id, r.name
    ORDER BY avg_rating DESC NULLS LAST
    LIMIT 10
  `

  const [ratings, countResult, readerAverages] = await Promise.all([
    query(q, params),
    query(countQuery, params.slice(0, -2)),
    query(avgQuery),
  ])

  return NextResponse.json({
    ratings,
    total: parseInt((countResult[0] as any)?.total || '0'),
    page,
    limit,
    readerAverages,
  })
}

export async function DELETE(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { id } = await req.json()
  if (!id) return NextResponse.json({ error: 'Missing id' }, { status: 400 })

  await query(`DELETE FROM reader_ratings WHERE id = $1`, [id])
  return NextResponse.json({ ok: true })
}
