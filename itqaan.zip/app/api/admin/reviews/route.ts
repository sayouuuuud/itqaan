import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import { query } from '@/lib/db'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const readerId = searchParams.get('readerId') || ''
  const verdict = searchParams.get('verdict') || ''
  const page = parseInt(searchParams.get('page') || '1')
  const limit = 20
  const offset = (page - 1) * limit

  let conditions: string[] = []
  let params: any[] = []
  let idx = 1

  if (readerId) { conditions.push(`rev.reader_id = $${idx++}`); params.push(readerId) }
  if (verdict) { conditions.push(`rev.verdict = $${idx++}`); params.push(verdict) }

  const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : ''

  const q = `
    SELECT
      rev.id, rev.verdict, rev.tajweed_score, rev.pronunciation_score,
      rev.fluency_score, rev.overall_score,
      rev.strengths, rev.areas_for_improvement, rev.detailed_feedback,
      rev.created_at,
      r.name AS reader_name,
      s.name AS student_name,
      rec.surah_name, rec.status AS recitation_status
    FROM reviews rev
    JOIN users r ON rev.reader_id = r.id
    JOIN recitations rec ON rev.recitation_id = rec.id
    JOIN users s ON rec.student_id = s.id
    ${where}
    ORDER BY rev.created_at DESC
    LIMIT $${idx++} OFFSET $${idx++}
  `
  params.push(limit, offset)

  const countQuery = `SELECT COUNT(*) AS total FROM reviews rev ${where}`

  const [reviews, countResult] = await Promise.all([
    query(q, params),
    query(countQuery, params.slice(0, -2)),
  ])

  return NextResponse.json({
    reviews,
    total: parseInt((countResult[0] as any)?.total || '0'),
    page,
    limit,
  })
}
