import { NextRequest, NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import { query } from '@/lib/db'

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session || session.role !== 'admin') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const { searchParams } = new URL(req.url)
  const dateFrom = searchParams.get('dateFrom') || ''
  const dateTo = searchParams.get('dateTo') || ''

  const dateFilter = dateFrom && dateTo
    ? `AND created_at BETWEEN '${dateFrom}' AND '${dateTo}T23:59:59Z'`
    : ''

  const [
    overallStats,
    recitationsByStatus,
    recitationsOverTime,
    masteryRate,
    topReaders,
    genderStats,
    sessionStats,
    cityStats,
  ] = await Promise.all([
    query(`
      SELECT
        (SELECT COUNT(*) FROM users WHERE role = 'student') AS total_students,
        (SELECT COUNT(*) FROM users WHERE role = 'reader' AND approval_status = 'approved') AS total_readers,
        (SELECT COUNT(*) FROM recitations ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : ''}) AS total_recitations,
        (SELECT COUNT(*) FROM recitations WHERE status = 'mastered' ${dateFilter}) AS total_mastered,
        (SELECT COUNT(*) FROM bookings WHERE status = 'completed' ${dateFilter}) AS total_sessions,
        (SELECT ROUND(COUNT(*) FILTER (WHERE status = 'mastered') * 100.0 / NULLIF(COUNT(*), 0), 1) FROM recitations ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : ''}) AS mastery_rate,
        (SELECT ROUND(AVG(rating), 2) FROM reader_ratings ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : ''}) AS avg_rating
    `),
    query(`
      SELECT status, COUNT(*) AS count
      FROM recitations
      ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : ''}
      GROUP BY status
    `),
    query(`
      SELECT TO_CHAR(created_at, 'Mon DD') AS date, COUNT(*) AS count
      FROM recitations
      ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : "WHERE created_at >= NOW() - INTERVAL '30 days'"}
      GROUP BY date, created_at::date
      ORDER BY created_at::date ASC
      LIMIT 30
    `),
    query(`
      SELECT
        TO_CHAR(DATE_TRUNC('month', created_at), 'Mon YYYY') AS month,
        ROUND(COUNT(*) FILTER (WHERE status = 'mastered') * 100.0 / NULLIF(COUNT(*), 0), 1) AS rate
      FROM recitations
      GROUP BY month, DATE_TRUNC('month', created_at)
      ORDER BY DATE_TRUNC('month', created_at) ASC
      LIMIT 12
    `),
    query(`
      SELECT u.name, COUNT(r.id) AS reviews,
        COUNT(r.id) FILTER (WHERE rev.verdict = 'mastered') AS mastered_count
      FROM users u
      LEFT JOIN recitations r ON u.id = r.assigned_reader_id
      LEFT JOIN reviews rev ON r.id = rev.recitation_id
      WHERE u.role = 'reader'
      GROUP BY u.name
      ORDER BY reviews DESC
      LIMIT 10
    `),
    query(`SELECT gender, COUNT(*) AS count FROM users WHERE role = 'student' GROUP BY gender`),
    query(`
      SELECT
        COUNT(*) FILTER (WHERE status = 'completed') AS completed,
        COUNT(*) FILTER (WHERE status = 'cancelled') AS cancelled,
        COUNT(*) FILTER (WHERE status = 'no_show') AS no_show,
        ROUND(AVG(duration_minutes) FILTER (WHERE status = 'completed'), 0) AS avg_duration
      FROM bookings
      ${dateFilter ? 'WHERE ' + dateFilter.substring(4) : ''}
    `),
    query(`
      SELECT u.city, COUNT(*) AS count
      FROM users u
      WHERE u.role = 'student' AND u.city IS NOT NULL
      GROUP BY u.city
      ORDER BY count DESC
      LIMIT 10
    `),
  ])

  return NextResponse.json({
    overall: overallStats[0],
    byStatus: recitationsByStatus,
    overTime: recitationsOverTime,
    masteryRate,
    topReaders,
    gender: genderStats,
    sessions: sessionStats[0],
    byCity: cityStats,
  })
}
