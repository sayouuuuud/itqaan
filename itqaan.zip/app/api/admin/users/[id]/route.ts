import { NextResponse } from 'next/server'
import { getSession } from '@/lib/auth'
import * as db from '@/lib/db'

export async function GET(
    req: Request,
    { params }: { params: { id: string } }
) {
    try {
        const session = await getSession()
        if (!session || session.role !== 'admin') {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
        }

        const userId = params.id

        // 1. Basic User Info (including phone)
        const user = await db.queryOne<any>(
            'SELECT id, name, email, phone, role, avatar_url, bio, is_active, created_at, last_login_at FROM users WHERE id = $1',
            [userId]
        )

        if (!user) {
            return NextResponse.json({ error: 'User not found' }, { status: 404 })
        }

        // 2. Recitation Metrics
        const dailyRec = await db.queryOne<any>(
            'SELECT COUNT(*) FROM recitations WHERE student_id = $1 AND created_at > NOW() - INTERVAL \'1 day\'',
            [userId]
        )
        const weeklyRec = await db.queryOne<any>(
            'SELECT COUNT(*) FROM recitations WHERE student_id = $1 AND created_at > NOW() - INTERVAL \'7 days\'',
            [userId]
        )
        const monthlyRec = await db.queryOne<any>(
            'SELECT COUNT(*) FROM recitations WHERE student_id = $1 AND created_at > NOW() - INTERVAL \'30 days\'',
            [userId]
        )

        // 3. Session Statistics (Bookings)
        // Completed Sessions
        const completedSessions = await db.queryOne<any>(
            'SELECT COUNT(*) FROM bookings WHERE (student_id = $1 OR reader_id = $1) AND status = \'completed\'',
            [userId]
        )
        // Absences / No-Shows
        const noShows = await db.queryOne<any>(
            'SELECT COUNT(*) FROM bookings WHERE (student_id = $1 OR reader_id = $1) AND status = \'no_show\'',
            [userId]
        )
        // Cancelled Sessions
        const cancelledSessions = await db.queryOne<any>(
            'SELECT COUNT(*) FROM bookings WHERE (student_id = $1 OR reader_id = $1) AND status = \'cancelled\'',
            [userId]
        )

        // 4. Ratings (if user is a reader)
        let averageRating = 0
        if (user.role === 'reader') {
            const ratingRes = await db.queryOne<any>(
                'SELECT AVG(rating) as avg FROM reader_ratings WHERE reader_id = $1',
                [userId]
            )
            averageRating = parseFloat(ratingRes?.avg || "0")
        }

        // 5. Last tech session Info
        const lastSession = await db.queryOne<any>(
            'SELECT ip_address, user_agent, last_active_at FROM user_sessions WHERE user_id = $1 ORDER BY last_active_at DESC LIMIT 1',
            [userId]
        )

        return NextResponse.json({
            user,
            metrics: {
                recitations: {
                    daily: parseInt(dailyRec?.count || "0"),
                    weekly: parseInt(weeklyRec?.count || "0"),
                    monthly: parseInt(monthlyRec?.count || "0")
                },
                sessions: {
                    completed: parseInt(completedSessions?.count || "0"),
                    noShow: parseInt(noShows?.count || "0"),
                    cancelled: parseInt(cancelledSessions?.count || "0")
                },
                rating: averageRating
            },
            lastSession
        })
    } catch (err) {
        console.error(err)
        return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
    }
}
