import { NextResponse } from "next/server"
import { getSession, requireRole } from "@/lib/auth"
import { query } from "@/lib/db"

export async function GET() {
  const session = await getSession()
  if (!session || !requireRole(session, ["student"])) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 })
  }

  const rows = await query(
    `SELECT r.id, r.surah_name, r.status, r.created_at, r.audio_url,
            r.student_notes, r.audio_duration_seconds,
            u.name as assigned_reader_name
     FROM recitations r
     LEFT JOIN users u ON r.assigned_reader_id = u.id
     WHERE r.student_id = $1
     ORDER BY r.created_at DESC
     LIMIT 1`,
    [session.sub]
  )

  if (rows.length === 0) {
    return NextResponse.json({ recitation: null })
  }

  return NextResponse.json({ recitation: rows[0] })
}
