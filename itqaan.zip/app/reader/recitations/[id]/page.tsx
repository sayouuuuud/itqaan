"use client"

import { useState, use, useEffect, useRef } from "react"
import Link from "next/link"
import { useI18n } from "@/lib/i18n/context"
import { tajweedTags } from "@/lib/mock-data"
import {
  Mic, Pause, Play, SkipBack, SkipForward, CheckCircle, AlertTriangle,
  Send, BookOpen, Plus, Loader2
} from "lucide-react"

export default function RecitationReviewDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: recitationId } = use(params)
  const { t, locale } = useI18n()
  const isAr = locale === 'ar'

  const [recitation, setRecitation] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")

  const [notes, setNotes] = useState("")
  const [result, setResult] = useState<"mastered" | "needs_session" | null>("mastered")
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [isPlaying, setIsPlaying] = useState(false)
  const [playbackSpeed, setPlaybackSpeed] = useState("1.0x")
  const [currentTime, setCurrentTime] = useState(0)
  const [duration, setDuration] = useState(0)

  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const waveformHeights = [8, 12, 16, 24, 10, 20, 14, 8, 6, 16, 28, 18, 10, 14, 20, 12, 8, 8, 12, 16, 24, 10, 20, 14, 8, 6, 16, 28, 18, 10, 14, 20, 12, 8]

  useEffect(() => {
    async function fetchRecitation() {
      try {
        const res = await fetch(`/api/recitations/${recitationId}`)
        if (!res.ok) throw new Error("Failed to fetch recitation")
        const data = await res.json()
        setRecitation(data.recitation)
        setDuration(data.recitation.audio_duration_seconds || 0)
      } catch (err) {
        setError(t.student.serverError)
        console.error(err)
      } finally {
        setLoading(false)
      }
    }
    fetchRecitation()
  }, [recitationId])

  useEffect(() => {
    if (audioRef.current && recitation?.audio_url) {
      const speed = parseFloat(playbackSpeed.replace("x", ""))
      audioRef.current.playbackRate = speed
    }
  }, [playbackSpeed, recitation])

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) => prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag])
  }

  const formatTime = (time: number) => {
    if (!time || isNaN(time)) return "00:00"
    const m = Math.floor(time / 60)
    const s = Math.floor(time % 60)
    return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
  }

  const togglePlay = () => {
    if (!audioRef.current) return
    if (isPlaying) {
      audioRef.current.pause()
    } else {
      audioRef.current.play()
    }
    setIsPlaying(!isPlaying)
  }

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime)
    }
  }

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!audioRef.current) return
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const percentage = x / rect.width
    const newTime = percentage * duration
    audioRef.current.currentTime = newTime
    setCurrentTime(newTime)
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center py-20">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    )
  }

  if (error || !recitation) {
    return (
      <div className="bg-red-50 text-red-600 p-6 rounded-xl text-center">
        {error || t.reader.recitationNotFound}
      </div>
    )
  }

  if (submitted || recitation.status !== 'pending') {
    return (
      <div className="max-w-2xl mx-auto text-center py-16">
        <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-8 h-8 text-emerald-600" />
        </div>
        <h2 className="text-xl font-bold text-foreground mb-2">{t.reader.reviewSubmittedSuccessfully}</h2>
        <p className="text-muted-foreground mb-6">{t.reader.studentWillBeNotified}</p>
        <div className="flex items-center justify-center gap-3">
          <Link href="/reader/recitations" className="px-6 py-2.5 bg-primary text-primary-foreground rounded-lg font-medium hover:bg-primary/90 transition-colors">{t.reader.backToRecitations}</Link>
          <Link href="/reader" className="px-6 py-2.5 border border-border rounded-lg font-medium text-foreground hover:bg-muted transition-colors">{t.reader.dashboard}</Link>
        </div>
      </div>
    )
  }

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0

  return (
    <div className="space-y-6">
      <audio
        ref={audioRef}
        src={recitation.audio_url}
        onTimeUpdate={handleTimeUpdate}
        onEnded={() => setIsPlaying(false)}
        onLoadedMetadata={(e) => {
          if (!duration) setDuration(e.currentTarget.duration)
        }}
      />

      <div>
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2 py-1 bg-blue-100 text-blue-700 text-xs font-semibold rounded">{t.reader.newRecitationBadge}</span>
                <h2 className="text-2xl font-bold text-foreground">{t.reader.studentNameLabel} {recitation.student_name}</h2>
              </div>
              <p className="text-muted-foreground flex items-center gap-2 text-sm">
                {t.reader.submittedOn} {new Date(recitation.created_at).toLocaleDateString(locale === 'ar' ? "ar-SA" : "en-US", { year: "numeric", month: "long", day: "numeric", hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </header>

          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Audio + Quran */}
            <section className="lg:col-span-7 space-y-6">
              {/* Audio Player Card */}
              <div className="bg-card rounded-2xl shadow-sm border border-border p-6 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-full h-1 bg-gradient-to-l from-primary to-transparent" />
                <div className="flex items-start justify-between mb-6">
                  <div>
                    <h3 className="text-lg font-bold text-foreground mb-1">{t.reader.surah} {recitation.surah_name}</h3>
                    <p className="text-sm text-muted-foreground">{t.reader.hafsNarrative}</p>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full text-primary">
                    <Mic className="w-5 h-5" />
                  </div>
                </div>

                {/* Waveform */}
                <div className="h-32 bg-muted/50 rounded-xl mb-6 flex items-center justify-center gap-[3px] px-4 overflow-hidden relative">
                  {waveformHeights.map((h, i) => (
                    <div
                      key={i}
                      className="w-1.5 bg-primary/50 rounded-full shrink-0"
                      style={{ height: `${h}px`, animationDelay: `${i * 100}ms` }}
                    />
                  ))}
                  <div
                    className="absolute left-0 top-0 bottom-0 border-r-2 border-destructive bg-primary/5 z-10 pointer-events-none transition-all duration-100"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>

                {/* Progress Bar */}
                <div className="space-y-4">
                  <div className="relative w-full h-2 bg-muted rounded-full cursor-pointer group" onClick={handleSeek}>
                    <div className="absolute h-full bg-primary rounded-full transition-all duration-100" style={{ width: `${progressPercentage}%` }} />
                    <div
                      className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-card border-2 border-primary rounded-full shadow cursor-grab transition-all duration-100"
                      style={{ left: `calc(${progressPercentage}% - 8px)` }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-muted-foreground font-mono">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>

                  {/* Controls */}
                  <div className="flex items-center justify-center gap-6 mt-2">
                    <button
                      onClick={() => { if (audioRef.current) audioRef.current.currentTime -= 5 }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <SkipBack className="w-6 h-6 rtl:rotate-180" />
                    </button>
                    <button
                      onClick={togglePlay}
                      className="bg-primary hover:bg-primary/90 text-primary-foreground w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-0.5"
                    >
                      {isPlaying ? <Pause className="w-7 h-7" /> : <Play className="w-7 h-7" />}
                    </button>
                    <button
                      onClick={() => { if (audioRef.current) audioRef.current.currentTime += 5 }}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      <SkipForward className="w-6 h-6 rtl:rotate-180" />
                    </button>
                  </div>

                  {/* Speed */}
                  <div className="flex justify-center mt-4">
                    <div className="inline-flex bg-muted rounded-lg p-1">
                      {["0.5x", "1.0x", "1.5x", "2.0x"].map((speed) => (
                        <button
                          key={speed}
                          onClick={() => setPlaybackSpeed(speed)}
                          className={`px-3 py-1 text-xs font-medium rounded transition ${playbackSpeed === speed ? "bg-card text-primary shadow-sm" : "text-muted-foreground hover:bg-card"
                            }`}
                        >
                          {speed}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Quran Text */}
              <div className="bg-card rounded-xl border border-border p-6">
                <h4 className="text-sm font-semibold text-muted-foreground mb-4 uppercase tracking-wider">{t.reader.quranTextLabel}</h4>
                <div className="text-center space-y-1" dir="rtl" style={{ fontFamily: "var(--font-quran)" }}>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"} <span className="text-[#D4A843] text-base align-middle">﴿١﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَٰلَمِينَ"} <span className="text-[#D4A843] text-base align-middle">﴿٢﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"ٱلرَّحْمَٰنِ ٱلرَّحِيمِ"} <span className="text-[#D4A843] text-base align-middle">﴿٣﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"مَٰلِكِ يَوْمِ ٱلدِّينِ"} <span className="text-[#D4A843] text-base align-middle">﴿٤﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ"} <span className="text-[#D4A843] text-base align-middle">﴿٥﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"ٱهْدِنَا ٱلصِّرَٰطَ ٱلْمُسْتَقِيمَ"} <span className="text-[#D4A843] text-base align-middle">﴿٦﴾</span>
                  </p>
                  <p className="text-[1.5rem] md:text-[1.7rem] leading-[2.6] text-foreground">
                    {"صِرَٰطَ ٱلَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ ٱلْمَغْضُوبِ عَلَيْهِمْ وَلَا ٱلضَّآلِّينَ"} <span className="text-[#D4A843] text-base align-middle">﴿٧﴾</span>
                  </p>
                </div>
              </div>
            </section>

            {/* Review Form */}
            <aside className="lg:col-span-5 flex flex-col h-full">
              <div className="bg-card rounded-2xl shadow-sm border border-border p-6 flex-1 flex flex-col">
                <h3 className="text-xl font-bold text-foreground mb-6 border-b border-border pb-4">{t.reader.assessmentAndNotes}</h3>

                <div className="flex flex-col h-full gap-6">
                  {/* Result Toggle */}
                  <div className="space-y-3">
                    <label className="block text-sm font-medium text-foreground">{t.reader.recitationResult}</label>
                    <div className="grid grid-cols-2 gap-4">
                      <label className="cursor-pointer">
                        <input type="radio" name="result" value="mastered" checked={result === "mastered"} onChange={() => setResult("mastered")} className="peer sr-only" />
                        <div className="p-4 rounded-xl border-2 border-border hover:bg-muted peer-checked:border-primary peer-checked:bg-primary/5 transition-all text-center flex flex-col items-center justify-center gap-2">
                          <CheckCircle className="w-6 h-6 text-primary" />
                          <span className="font-bold text-foreground">{t.reader.masteredOption}</span>
                          <span className="text-xs text-muted-foreground">{t.reader.masteredOptionDesc}</span>
                        </div>
                      </label>
                      <label className="cursor-pointer">
                        <input type="radio" name="result" value="needs_session" checked={result === "needs_session"} onChange={() => setResult("needs_session")} className="peer sr-only" />
                        <div className="p-4 rounded-xl border-2 border-border hover:bg-muted peer-checked:border-[#D4A843] peer-checked:bg-[#D4A843]/5 transition-all text-center flex flex-col items-center justify-center gap-2">
                          <AlertTriangle className="w-6 h-6 text-[#D4A843]" />
                          <span className="font-bold text-foreground">{t.reader.needsSessionOption}</span>
                          <span className="text-xs text-muted-foreground">{t.reader.needsSessionOptionDesc}</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Notes */}
                  <div className="flex-1 flex flex-col space-y-3">
                    <div className="flex justify-between items-center">
                      <label className="block text-sm font-medium text-foreground">{t.student.readerNotes}</label>
                      <button type="button" className="text-xs text-primary hover:text-primary/80 font-medium flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        {t.reader.smartSuggestions}
                      </button>
                    </div>
                    <div className="relative flex-1">
                      <textarea
                        className="w-full h-full min-h-[180px] p-4 bg-muted/30 border border-border rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent resize-none text-foreground leading-relaxed"
                        placeholder={t.reader.notesPlaceholder}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                      />
                      <div className="absolute bottom-4 left-4 flex gap-2">
                        <button type="button" className="p-1.5 bg-card rounded-md shadow-sm border border-border text-muted-foreground hover:text-primary transition" title={t.reader.audioNoteTooltip}>
                          <Mic className="w-4 h-4" />
                        </button>
                        <button type="button" className="p-1.5 bg-card rounded-md shadow-sm border border-border text-muted-foreground hover:text-primary transition" title={t.reader.insertAyahTooltip}>
                          <BookOpen className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Tags */}
                  <div className="space-y-2">
                    <label className="block text-xs font-semibold text-muted-foreground uppercase tracking-wider">{t.reader.quickTagsHeader}</label>
                    <div className="flex flex-wrap gap-2">
                      {tajweedTags.slice(0, 4).map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() => setNotes(prev => prev ? `${prev}\n${tag}` : tag)}
                          className="px-3 py-1.5 rounded-full text-xs transition bg-muted text-muted-foreground hover:bg-muted/80"
                        >
                          {tag}
                        </button>
                      ))}
                      <button type="button" className="px-3 py-1.5 border border-dashed border-border text-muted-foreground rounded-full text-xs hover:border-primary hover:text-primary transition flex items-center gap-1">
                        <Plus className="w-3 h-3" />
                        {t.reader.good}
                      </button>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3 pt-4 border-t border-border">
                    <button
                      onClick={async () => {
                        if (!result) return
                        setSubmitting(true)
                        try {
                          const res = await fetch(`/api/recitations/${recitationId}/review`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                              verdict: result,
                              feedback: notes,
                              overallScore: result === "mastered" ? 100 : 50,
                            }),
                          })
                          if (res.ok) {
                            setSubmitted(true)
                          } else {
                            throw new Error("حدث خطأ")
                          }
                        } catch (err) {
                          console.error("Review submit error:", err)
                          alert("حدث خطأ أثناء حفظ التقييم")
                        } finally {
                          setSubmitting(false)
                        }
                      }}
                      disabled={!result || submitting || submitted}
                      className="flex-1 py-3 px-6 bg-primary text-primary-foreground rounded-xl font-bold text-sm hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {submitted ? t.reader.decisionSaved : submitting ? t.reader.savingNow : t.reader.saveDecision}
                    </button>
                  </div>
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  )
}

