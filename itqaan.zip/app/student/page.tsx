"use client"

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { useI18n } from '@/lib/i18n/context'
import { Mic, Clock, CheckCircle, Calendar, ArrowLeft, Video, MessageSquare, Send } from 'lucide-react'

type FatihaStatus = 'no_recitation' | 'pending' | 'in_review' | 'mastered' | 'needs_session' | 'session_booked'

interface LatestRecitation {
  status: FatihaStatus
  created_at?: string
}

interface BookingInfo {
  id: string
  slot_start: string
  slot_end: string
  meeting_link?: string
  reader_name?: string
}

function useStudentData() {
  const [recitation, setRecitation] = useState<LatestRecitation | null>(null)
  const [booking, setBooking] = useState<BookingInfo | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch('/api/recitations/my-latest')
        if (res.ok) {
          const data = await res.json()
          if (data.recitation) {
            setRecitation(data.recitation)
            // If session_booked, also fetch the booking details
            if (data.recitation.status === 'session_booked') {
              const bookRes = await fetch('/api/bookings')
              if (bookRes.ok) {
                const bookData = await bookRes.json()
                // Get the most recent confirmed/pending booking
                const bookings = bookData.bookings || []
                const latestBooking = bookings.find(
                  (b: BookingInfo & { status: string }) =>
                    ['confirmed', 'pending'].includes(b.status)
                )
                if (latestBooking) setBooking(latestBooking)
              }
            }
          } else {
            setRecitation({ status: 'no_recitation' })
          }
        } else {
          setRecitation({ status: 'no_recitation' })
        }
      } catch {
        setRecitation({ status: 'no_recitation' })
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  return { recitation, booking, loading }
}

export default function StudentDashboard() {
  const { t, locale } = useI18n()
  const { recitation, booking, loading } = useStudentData()

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-[#0B3D2E]/20 border-t-[#0B3D2E] rounded-full animate-spin" />
      </div>
    )
  }

  const status = recitation?.status || 'no_recitation'

  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center py-10 px-4">
      <div className="w-full max-w-xl mx-auto text-center space-y-8">
        {/* Title */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-slate-800">{t.student.dashboard}</h1>
          <p className="text-slate-500">{t.student.fatihaStatus}</p>
        </div>

        {/* State: No recitation yet */}
        {status === 'no_recitation' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm text-center space-y-6">
            <div className="w-20 h-20 bg-[#D4A843]/10 rounded-full flex items-center justify-center mx-auto">
              <Mic className="w-10 h-10 text-[#D4A843]" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-slate-800">{t.student.noRecitationTitle}</h2>
              <p className="text-slate-500 text-sm leading-relaxed">{t.student.noRecitationDesc}</p>
            </div>
            <Link href="/student/submit" className="inline-flex items-center gap-2 bg-[#D4A843] hover:bg-[#C49A3A] text-white font-bold py-3.5 px-8 rounded-xl transition-colors shadow-lg shadow-[#D4A843]/20">
              <Mic className="w-5 h-5" />
              <span>{t.student.recordNowBtn}</span>
            </Link>
          </div>
        )}

        {/* State: Pending / In Review */}
        {(status === 'pending' || status === 'in_review') && (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm text-center space-y-6">
            <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto">
              <Clock className="w-10 h-10 text-amber-500" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-slate-800">{t.student.recitationReceived}</h2>
              <p className="text-slate-500 text-sm leading-relaxed">
                {t.student.recitationReceivedDesc}
              </p>
            </div>
            <div className="bg-amber-50 border border-amber-100 rounded-xl p-4">
              <p className="text-sm font-medium text-amber-700 mb-1">{t.student.statusInReviewBanner}</p>
              <p className="text-xs text-amber-600/80">
                {t.student.reviewTakesTime}
              </p>
            </div>
          </div>
        )}

        {/* State: Mastered */}
        {status === 'mastered' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm text-center space-y-6">
            <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle className="w-10 h-10 text-emerald-600" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-emerald-700">{t.student.congratsMastered}</h2>
              <p className="text-slate-500 text-sm leading-relaxed">
                {t.student.masteredDesc}
              </p>
            </div>
            {/* Certificate section - conditional on system setting */}
            <Link href="/student/certificate" className="inline-flex items-center gap-2 bg-[#0B3D2E] hover:bg-[#0A3528] text-white font-bold py-3.5 px-8 rounded-xl transition-colors">
              <span>{t.student.completeCertData}</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>
        )}

        {/* State: Needs Session */}
        {status === 'needs_session' && (
          <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-sm text-center space-y-6">
            <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto">
              <Calendar className="w-10 h-10 text-blue-600" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold text-slate-800">{t.student.needsSessionTitle}</h2>
              <p className="text-slate-500 text-sm leading-relaxed">
                {t.student.needsSessionDesc}
              </p>
            </div>
            <Link href="/student/booking" className="inline-flex items-center gap-2 bg-[#D4A843] hover:bg-[#C49A3A] text-white font-bold py-3.5 px-8 rounded-xl transition-colors shadow-lg shadow-[#D4A843]/20">
              <Calendar className="w-5 h-5" />
              <span>{t.student.bookSessionBtnBase}</span>
            </Link>
          </div>
        )}

        {/* State: Session Booked */}
        {status === 'session_booked' && booking && (
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm text-right space-y-0">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 text-center">
              <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Video className="w-8 h-8 text-purple-600" />
              </div>
              <h2 className="text-xl font-bold text-slate-800">{t.student.appointmentDetails}</h2>
              <div className="inline-flex items-center gap-2 mt-2 bg-purple-50 text-purple-700 px-4 py-1.5 rounded-full text-sm font-medium">
                <span>{t.student.bookedStatus}</span>
              </div>
            </div>

            {/* Appointment Details */}
            <div className="p-6 space-y-4">
              <div className="flex justify-between items-center py-2 border-b border-slate-50">
                <span className="text-sm text-slate-500">{t.student.sessionDate}</span>
                <span className="text-sm font-bold text-slate-800">
                  {new Date(booking.slot_start).toLocaleDateString(locale === 'ar' ? 'ar-SA' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-50">
                <span className="text-sm text-slate-500">{t.student.sessionTime}</span>
                <span className="text-sm font-bold text-slate-800">
                  {new Date(booking.slot_start).toLocaleTimeString(locale === 'ar' ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                  {' - '}
                  {new Date(booking.slot_end).toLocaleTimeString(locale === 'ar' ? 'ar-SA' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>

              {/* Meeting Link - Separate Field */}
              <div className="py-3 border-b border-slate-50">
                <span className="text-sm text-slate-500 block mb-2">{t.student.sessionLinkLabel}</span>
                {booking.meeting_link ? (
                  <a
                    href={booking.meeting_link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-[#0B3D2E] hover:bg-[#0A3528] text-white font-bold py-2.5 px-6 rounded-xl transition-colors text-sm"
                  >
                    <Video className="w-4 h-4" />
                    <span>{t.student.joinSessionBtn}</span>
                  </a>
                ) : (
                  <p className="text-sm text-slate-400">{t.student.linkPendingMsg}</p>
                )}
              </div>

              {/* Comments Section */}
              <div className="py-3">
                <div className="flex items-center gap-2 mb-3">
                  <MessageSquare className="w-4 h-4 text-slate-500" />
                  <span className="text-sm text-slate-500">{t.student.commentLabel}</span>
                </div>
                <CommentBox bookingId={booking.id} />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

function CommentBox({ bookingId }: { bookingId: string }) {
  const { t, locale } = useI18n()
  const [comments, setComments] = useState<Array<{ id: string; user_name: string; comment_text: string; created_at: string }>>([])
  const [newComment, setNewComment] = useState('')
  const [sending, setSending] = useState(false)

  useEffect(() => {
    fetch(`/api/bookings/${bookingId}/comments`)
      .then(r => r.ok ? r.json() : { comments: [] })
      .then(d => setComments(d.comments || []))
      .catch(() => { })
  }, [bookingId])

  const handleSend = async () => {
    if (!newComment.trim()) return
    setSending(true)
    try {
      const res = await fetch(`/api/bookings/${bookingId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: newComment }),
      })
      if (res.ok) {
        const data = await res.json()
        setComments(prev => [...prev, data.comment])
        setNewComment('')
      }
    } catch {
      // ignore
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="space-y-3">
      {comments.length > 0 && (
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {comments.map(c => (
            <div key={c.id} className="bg-slate-50 rounded-lg p-3 text-right">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-slate-400">{new Date(c.created_at).toLocaleString(locale === 'ar' ? 'ar-SA' : 'en-US')}</span>
                <span className="text-xs font-bold text-slate-600">{c.user_name}</span>
              </div>
              <p className="text-sm text-slate-700">{c.comment_text}</p>
            </div>
          ))}
        </div>
      )}
      <div className="flex gap-2">
        <button
          onClick={handleSend}
          disabled={!newComment.trim() || sending}
          className="px-4 py-2.5 bg-[#0B3D2E] text-white rounded-xl text-sm font-medium hover:bg-[#0A3528] disabled:opacity-50 transition-colors"
        >
          <Send className="w-4 h-4" />
        </button>
        <input
          type="text"
          value={newComment}
          onChange={e => setNewComment(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSend()}
          placeholder={t.student.writeCommentPlaceholder}
          className="flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-700 focus:ring-2 focus:ring-[#0B3D2E]/20 focus:border-[#0B3D2E] placeholder:text-slate-400"
        />
      </div>
    </div>
  )
}
