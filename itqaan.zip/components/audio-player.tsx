'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Slider } from '@/components/ui/slider'
import { Play, Pause, RotateCcw } from 'lucide-react'

export function AudioPlayer({ duration = '02:15' }: { duration?: string }) {
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(0)

  return (
    <div className="bg-secondary rounded-xl p-4">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          className="rounded-full shrink-0 w-10 h-10 border-primary/30 text-primary hover:bg-primary/10"
          onClick={() => setPlaying(!playing)}
          aria-label={playing ? 'إيقاف' : 'تشغيل'}
        >
          {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 mr-[-2px]" />}
        </Button>

        <div className="flex-1 space-y-2">
          {/* Waveform visualization (mock) */}
          <div className="flex items-center gap-[2px] h-8">
            {Array.from({ length: 40 }).map((_, i) => {
              const height = Math.random() * 100
              const isPlayed = (i / 40) * 100 <= progress
              return (
                <div
                  key={i}
                  className="flex-1 rounded-full transition-colors"
                  style={{
                    height: `${Math.max(15, height)}%`,
                    backgroundColor: isPlayed ? 'var(--primary)' : 'var(--border)',
                  }}
                />
              )
            })}
          </div>
          <Slider
            value={[progress]}
            onValueChange={(v) => setProgress(v[0])}
            max={100}
            step={1}
            className="cursor-pointer"
          />
        </div>

        <div className="text-xs text-muted-foreground font-mono shrink-0 tabular-nums">
          {duration}
        </div>

        <Button
          variant="ghost"
          size="icon-sm"
          className="text-muted-foreground shrink-0"
          onClick={() => { setProgress(0); setPlaying(false) }}
          aria-label="إعادة"
        >
          <RotateCcw className="w-4 h-4" />
        </Button>
      </div>
    </div>
  )
}
