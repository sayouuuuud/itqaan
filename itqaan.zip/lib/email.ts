// Email helper - placeholder ready to be connected to any email service
// Supported services: Resend, Nodemailer, SendGrid
// Set EMAIL_SERVICE and relevant API keys in environment variables

interface EmailOptions {
  to: string
  subject: string
  body: string
  html?: string
}

import { Resend } from 'resend'

export async function sendEmail({ to, subject, body, html }: EmailOptions): Promise<boolean> {
  if (!process.env.RESEND_API_KEY) {
    console.log(`[Email DEV MODE] Sending to: ${to}, Subject: ${subject}`)
    console.log(`[Email] HTML/Body:`, html || body)
    return true
  }

  // Lazy initialization: only create Resend client when actually sending
  const resend = new Resend(process.env.RESEND_API_KEY)

  try {
    await resend.emails.send({
      from: 'إتقان <onboarding@resend.dev>',
      to,
      subject,
      html: html || body,
    })
    return true
  } catch (error) {
    console.error("[Email] Failed to send:", error)
    return false
  }
}

// Basic verification email doesn't need to be in the DB to keep Auth standalone
export function sendVerificationEmail(to: string, userName: string, code: string) {
  return sendEmail({
    to,
    subject: "كود تفعيل حسابك - إتقان الفاتحة",
    body: `كود التفعيل الخاص بك هو: ${code}`,
    html: `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 10px;">
        <h2 style="color: #0B3D2E;">أهلاً بك يا ${userName} في منصة إتقان الفاتحة</h2>
        <p style="font-size: 16px; color: #475569;">شكراً لتسجيلك معنا. لتفعيل حسابك، يرجى استخدام الكود التالي:</p>
        
        <div style="background-color: #f8fafc; padding: 15px; text-align: center; border-radius: 8px; margin: 20px 0;">
          <span style="font-size: 32px; font-weight: bold; letter-spacing: 5px; color: #D4A843;">${code}</span>
        </div>
        
        <p style="font-size: 14px; color: #64748b;">هذا الكود صالح لمدة 24 ساعة فقط.</p>
        <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;" />
        <p style="font-size: 12px; color: #94a3b8; text-align: center;">إذا لم تقم بإنشاء هذا الحساب، يرجى تجاهل هذه الرسالة.</p>
      </div>
    `,
  })
}

// Helper to fetch and render dynamic templates
import { queryOne } from '@/lib/db'

async function sendDynamicEmail(templateKey: string, to: string, variables: Record<string, string>) {
  try {
    const template = await queryOne<{ subject_ar: string; body_ar: string; is_active: boolean }>(
      `SELECT subject_ar, body_ar, is_active FROM email_templates WHERE template_key = $1`,
      [templateKey]
    )

    if (!template) {
      console.warn(`[Email] Template ${templateKey} not found in DB.`)
      return false
    }

    if (!template.is_active) {
      console.log(`[Email] Template ${templateKey} is disabled. Skipping.`)
      return true
    }

    let subject = template.subject_ar
    let body = template.body_ar

    // Replace variables (e.g., {{studentName}})
    for (const [key, value] of Object.entries(variables)) {
      const regex = new RegExp(`{{${key}}}`, 'g')
      subject = subject.replace(regex, value)
      body = body.replace(regex, value)
    }

    // Convert newlines to HTML lines (simple rendering)
    const htmlBody = `
      <div dir="rtl" style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; color: #333;">
        ${body.split('\\n').map((line: string) => `<p>${line}</p>`).join('')}
      </div>
    `

    return sendEmail({
      to,
      subject,
      body,
      html: htmlBody
    })
  } catch (error) {
    console.error(`[Email] Error sending dynamic template ${templateKey}:`, error)
    return false
  }
}

// Pre-built email templates mapping
export function sendMasteredEmail(to: string, studentName: string) {
  return sendDynamicEmail("recitation_mastered", to, { studentName })
}

export function sendNeedsSessionEmail(to: string, studentName: string) {
  return sendDynamicEmail("recitation_needs_session", to, { studentName })
}

export function sendReaderApprovedEmail(to: string, readerName: string) {
  return sendDynamicEmail("reader_approved", to, { readerName })
}

export function sendReaderRejectedEmail(to: string, readerName: string) {
  return sendDynamicEmail("reader_rejected", to, { readerName })
}

export function sendCertificateIssuedEmail(to: string, studentName: string, certificateLink: string) {
  return sendDynamicEmail("certificate_issued", to, { studentName, certificateLink })
}
